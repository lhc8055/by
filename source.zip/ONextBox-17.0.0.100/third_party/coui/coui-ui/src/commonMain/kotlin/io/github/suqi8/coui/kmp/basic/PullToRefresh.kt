// Copyright 2025, compose-coui-ui contributors
// SPDX-License-Identifier: Apache-2.0
package io.github.suqi8.coui.kmp.basic

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.takeOrElse
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalWindowInfo
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.Velocity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import io.github.suqi8.coui.kmp.theme.COUITheme
import io.github.suqi8.coui.kmp.utils.LocalOverScrollState
import io.github.suqi8.coui.kmp.utils.OverScrollState
import io.github.suqi8.coui.kmp.utils.SpringEngine
import io.github.suqi8.coui.kmp.utils.SpringMath
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sign
import kotlin.math.sin

/**
 * A container that supports the "pull-to-refresh" gesture.
 *
 * This composable follows a hoisted state pattern, where the logical `isRefreshing` state
 * is managed by the caller (e.g., a ViewModel). It coordinates nested scrolling to enable a
 * pull-to-refresh action, displays a customizable indicator, and triggers a callback when a
 * refresh is requested.
 *
 * @param isRefreshing A boolean state representing whether a refresh is currently in progress.
 * This state should be hoisted and is the source of truth for the refresh operation.
 * @param onRefresh A lambda to be invoked when a refresh is triggered by the user. This lambda
 * should initiate the data loading and is responsible for eventually setting `isRefreshing`
 * back to `false` upon completion.
 * @param modifier The modifier to be applied to this container.
 * @param pullToRefreshState The state object that manages the UI and animations of the indicator.
 * See [rememberPullToRefreshState].
 * @param contentPadding The padding to be applied to the content. The top padding is used to
 * correctly offset the refresh indicator.
 * @param topAppBarScrollBehavior An optional [ScrollBehavior] for a `TopAppBar` to coordinate
 * scrolling between the app bar and the pull-to-refresh gesture.
 * @param color The color of the refresh indicator. If [Color.Unspecified], the theme
 * primary color is used.
 * @param circleSize The size of the refresh indicator's animated circle.
 * @param refreshTexts A list of strings representing the text shown in different states.
 * @param refreshTextStyle The [TextStyle] for the refresh indicator text.
 * @param content The content to be displayed inside the container.
 */
@Composable
fun PullToRefresh(
    isRefreshing: Boolean,
    onRefresh: () -> Unit,
    modifier: Modifier = Modifier,
    pullToRefreshState: PullToRefreshState = rememberPullToRefreshState(),
    contentPadding: PaddingValues = PaddingValues(0.dp),
    topAppBarScrollBehavior: ScrollBehavior? = null,
    color: Color = PullToRefreshDefaults.color,
    circleSize: Dp = PullToRefreshDefaults.circleSize,
    refreshTexts: List<String> = PullToRefreshDefaults.refreshTexts,
    refreshTextStyle: TextStyle = PullToRefreshDefaults.refreshTextStyle,
    content: @Composable () -> Unit,
) {
    val coroutineScope = rememberCoroutineScope()
    val overScrollState = LocalOverScrollState.current
    val currentOnRefresh by rememberUpdatedState(onRefresh)

    // The indicator follows COUILoadingView theming (couiLoadingViewColor = couiColorPrimary).
    val indicatorColor = color.takeOrElse { COUITheme.colorScheme.primary }

    LaunchedEffect(isRefreshing) {
        if (!isRefreshing && pullToRefreshState.refreshState == RefreshState.Refreshing) {
            // Data loading completed, end refresh
            pullToRefreshState.finishRefreshing()
        }
    }

    // This connection establishes the chain of responsibility for nested scroll events.
    val nestedScrollConnection =
        remember(pullToRefreshState, topAppBarScrollBehavior, overScrollState) {
            // Reset cached connection when dependencies change
            pullToRefreshState.cachedNestedScrollConnection = null
            createPullToRefreshConnection(
                pullToRefreshState,
                topAppBarScrollBehavior,
                overScrollState,
            )
        }

    // A modifier to detect when the user releases their finger and trigger the refresh logic.
    val pointerModifier = remember(pullToRefreshState) {
        Modifier.pointerInput(Unit) {
            awaitPointerEventScope {
                while (true) {
                    val event = awaitPointerEvent()
                    if (
                        (pullToRefreshState.refreshState == RefreshState.Pulling || pullToRefreshState.refreshState == RefreshState.ThresholdReached) &&
                        event.changes.all { !it.pressed }
                    ) {
                        coroutineScope.launch {
                            pullToRefreshState.handlePointerRelease(currentOnRefresh)
                        }
                    }
                }
            }
        }
    }

    CompositionLocalProvider(
        LocalPullToRefreshState provides pullToRefreshState,
    ) {
        val boxModifier = remember(modifier, nestedScrollConnection, pointerModifier) {
            modifier
                .nestedScroll(nestedScrollConnection)
                .then(pointerModifier)
        }

        Box(modifier = boxModifier) {
            Column {
                RefreshHeader(
                    pullToRefreshState = pullToRefreshState,
                    circleSize = circleSize,
                    color = indicatorColor,
                    refreshTexts = refreshTexts,
                    refreshTextStyle = refreshTextStyle,
                    modifier = Modifier.offset(y = contentPadding.calculateTopPadding()),
                )
                content()
            }
        }
    }
}

/**
 * Creates and remembers a [PullToRefreshState] across recompositions.
 *
 * This state object is responsible for managing the visual aspects of the refresh indicator,
 * such as its position and animation. The logical `isRefreshing` state should be hoisted and
 * managed separately.
 *
 * @return A remembered instance of [PullToRefreshState].
 */
@Composable
fun rememberPullToRefreshState(): PullToRefreshState {
    val coroutineScope = rememberCoroutineScope()

    // The state object is created using `remember` as it's a runtime UI state manager.
    // The logical `isRefreshing` state, which survives process death, is hoisted.
    val state = remember {
        PullToRefreshState(coroutineScope)
    }

    // Update context-dependent properties on the state instance to ensure it's always current.
    val windowInfo = LocalWindowInfo.current
    state.maxDragDistancePx = windowInfo.containerSize.height.toFloat()
    state.refreshThresholdOffset = windowInfo.containerSize.height.toFloat() * MAX_DRAWRATIO * THRESHOLD_RADIO

    return state
}

/** Represents the various visual states of the pull-to-refresh indicator. */
sealed interface RefreshState {
    data object Idle : RefreshState
    data object Pulling : RefreshState
    data object ThresholdReached : RefreshState
    data object Refreshing : RefreshState
    data object RefreshComplete : RefreshState
}

/**
 * A UI state holder for the [PullToRefresh] composable.
 *
 * This class manages the internal state machine for animations and nested scroll interactions,
 * driven by the hoisted `isRefreshing` boolean.
 *
 * @param coroutineScope A [CoroutineScope] used to launch animations and state updates.
 */
class PullToRefreshState(
    internal var coroutineScope: CoroutineScope,
) {
    internal var maxDragDistancePx: Float = 0f
    internal var refreshThresholdOffset: Float = 0f

    /** The drag offset in pixels. */
    var dragOffset by mutableFloatStateOf(0f)

    /** Cached NestedScrollConnection to avoid creating new instances on every scroll event. */
    var cachedNestedScrollConnection: NestedScrollConnection? = null

    private var internalRefreshState by mutableStateOf<RefreshState>(RefreshState.Idle)

    /** The current visual [RefreshState] of the component. */
    val refreshState: RefreshState get() = internalRefreshState

    /** The progress of the pull gesture, from 0.0 to 1.0, until the threshold is reached. */
    val pullProgress: Float by derivedStateOf {
        if (refreshThresholdOffset > 0f) {
            (dragOffset / refreshThresholdOffset).coerceIn(0f, 1f)
        } else {
            0f
        }
    }

    internal var currentTouch by mutableFloatStateOf(0f)

    internal var isRefreshing by mutableStateOf(false)
    internal var isTouching by mutableStateOf(false)
    internal var isRebounding by mutableStateOf(false)
    private var isProcessingRelease = false
    private val refreshCompleteAnimProgressState = mutableFloatStateOf(1f)
    internal val refreshCompleteAnimProgress: Float get() = refreshCompleteAnimProgressState.floatValue

    // Physics Engine for rebound
    private val springEngine = SpringEngine()
    internal var animationJob: Job? = null

    /**
     * Drives the dragOffset using SpringEngine physics.
     * Runs the animation loop directly in the caller's coroutine context,
     * so cancellation of the caller naturally stops the animation.
     */
    internal suspend fun animateToSpring(targetValue: Float) {
        animationJob?.cancel()

        springEngine.start(
            startValue = dragOffset,
            targetValue = targetValue,
            initialVel = 0f,
        )

        val currentJob = currentCoroutineContext()[Job]
        animationJob = currentJob

        var lastFrameTimeNanos = -1L
        var isFinished = false

        try {
            while (currentCoroutineContext().isActive) {
                isFinished = withFrameNanos { frameTimeNanos ->
                    if (lastFrameTimeNanos == -1L) {
                        lastFrameTimeNanos = frameTimeNanos
                        return@withFrameNanos false
                    }
                    val dt = (frameTimeNanos - lastFrameTimeNanos) / 1_000_000_000f
                    lastFrameTimeNanos = frameTimeNanos

                    val finished = springEngine.step(dt)
                    val newOffset = springEngine.currentPos.toFloat()

                    // Directly update the state
                    dragOffset = newOffset

                    // Crucial: Update currentTouch using inverse damping so that if user catches
                    // the list mid-animation, the touch tracking is consistent with visual position.
                    currentTouch = SpringMath.obtainTouchDistance(newOffset, maxDragDistancePx)

                    finished
                }
                if (isFinished) break
            }
        } finally {
            if (animationJob == currentJob) animationJob = null
            if (isFinished) {
                // Ensure we land exactly on target after normal completion
                dragOffset = targetValue
                currentTouch = SpringMath.obtainTouchDistance(targetValue, maxDragDistancePx)
            }
        }
    }

    /**
     * Enter the refresh queue
     */
    internal suspend fun startRefreshing(onRefresh: () -> Unit) {
        if (!isRefreshing) {
            isRefreshing = true
            try {
                // Use spring to move to threshold
                animateToSpring(refreshThresholdOffset)
            } finally {
                if (!isTouching) {
                    internalRefreshState = RefreshState.Refreshing
                    onRefresh()
                } else {
                    isRefreshing = false
                }
            }
        }
    }

    /**
     * Called when the hoisted `isRefreshing` state becomes false.
     * Triggers the completion animation and resets the state.
     */
    internal suspend fun finishRefreshing() {
        if (isRefreshing) {
            isRefreshing = false
            internalRefreshState = RefreshState.RefreshComplete
            startManualRefreshCompleteAnimation()
        }
    }

    /** Handles the pointer release event to either trigger a refresh or rebound the indicator. */
    internal suspend fun handlePointerRelease(onRefresh: () -> Unit) {
        isTouching = false

        if (isProcessingRelease || isRefreshing || isRebounding) return
        isProcessingRelease = true
        try {
            if (dragOffset >= refreshThresholdOffset) {
                // If pulled past threshold, will then call startRefreshing().
                startRefreshing(onRefresh)
            } else {
                // If not pulled past threshold, rebound to the resting state using spring.
                try {
                    isRebounding = true
                    animateToSpring(0f)
                } finally {
                    isRebounding = false
                    resetToIdle()
                }
            }
        } finally {
            isProcessingRelease = false
        }
    }

    private suspend fun startManualRefreshCompleteAnimation() {
        refreshCompleteAnimProgressState.floatValue = 0f
        val animatedValue = Animatable(0f)
        animatedValue.animateTo(
            targetValue = 1f,
            animationSpec = tween<Float>(durationMillis = 200, easing = CubicBezierEasing(0f, 0f, 0f, 0.37f)),
        ) {
            refreshCompleteAnimProgressState.floatValue = this.value
        }
        internalResetState()
    }

    private suspend fun internalResetState() {
        internalRefreshState = RefreshState.Idle
        // Animate back to 0 using Spring
        animateToSpring(0f)
    }

    /** Resets the refresh state to [RefreshState.Idle]. */
    internal fun resetToIdle() {
        if (internalRefreshState != RefreshState.Refreshing && internalRefreshState != RefreshState.RefreshComplete) {
            internalRefreshState = RefreshState.Idle
        }
    }

    /** Creates a [NestedScrollConnection] for the pull-to-refresh logic itself. */
    internal fun getOrCreateNestedScrollConnection(
        overScrollState: OverScrollState,
    ): NestedScrollConnection {
        // Return cached instance if already created to avoid allocations during scrolling
        cachedNestedScrollConnection?.let { return it }

        return (
            object : NestedScrollConnection {
                private fun applyDrag(delta: Float) {
                    if (delta == 0f) return
                    currentTouch += delta
                    currentTouch = currentTouch.coerceIn(-maxDragDistancePx, maxDragDistancePx)

                    val normalized = min(abs(currentTouch) / maxDragDistancePx, 1.0f)
                    val dampedDist = SpringMath.obtainDampingDistance(normalized, maxDragDistancePx)
                    dragOffset = sign(currentTouch) * dampedDist

                    when {
                        refreshThresholdOffset > 0f && dragOffset >= refreshThresholdOffset -> RefreshState.ThresholdReached
                        dragOffset > 0 -> RefreshState.Pulling
                        else -> RefreshState.Idle
                    }.also { nextState ->
                        if (refreshState != nextState) {
                            internalRefreshState = nextState
                        }
                    }
                }

                override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                    // Only defer to overscroll when refresh is idle.
                    if (overScrollState.isOverScrollActive && refreshState == RefreshState.Idle) return Offset.Zero
                    // If the refresh is in progress, consume all scroll events.
                    if (refreshState == RefreshState.Refreshing || refreshState == RefreshState.RefreshComplete) {
                        return available
                    }

                    // When pulling up while the indicator is visible, consume the scroll to hide it.
                    if (source == NestedScrollSource.UserInput && available.y < 0 && (dragOffset > 0f || currentTouch > 0f)) {
                        isTouching = true
                        animationJob?.cancel()
                        applyDrag(available.y)
                        return Offset(0f, available.y)
                    }
                    return Offset.Zero
                }

                override fun onPostScroll(consumed: Offset, available: Offset, source: NestedScrollSource): Offset {
                    // If the refresh is in progress, consume all scroll events.
                    if (refreshState == RefreshState.Refreshing || refreshState == RefreshState.RefreshComplete) {
                        return available
                    }

                    // When pulling down after the content is at its top, consume the scroll to show the indicator.
                    if (source == NestedScrollSource.UserInput && available.y > 0f) {
                        isTouching = true
                        animationJob?.cancel()
                        applyDrag(available.y)
                        return Offset(0f, available.y)
                    }
                    return Offset.Zero
                }
            }
            ).also { cachedNestedScrollConnection = it }
    }
}

/**
 * A factory function to create the main [NestedScrollConnection] for the [PullToRefresh] component.
 */
private fun createPullToRefreshConnection(
    pullToRefreshState: PullToRefreshState,
    topAppBarScrollBehavior: ScrollBehavior?,
    overScrollState: OverScrollState,
): NestedScrollConnection = object : NestedScrollConnection {
    override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
        when (pullToRefreshState.refreshState) {
            RefreshState.Idle -> {
                val consumedByAppBar = topAppBarScrollBehavior?.nestedScrollConnection?.onPreScroll(available, source) ?: Offset.Zero
                val remaining = available - consumedByAppBar
                val consumedByRefresh = pullToRefreshState
                    .getOrCreateNestedScrollConnection(overScrollState)
                    .onPreScroll(remaining, source)
                return consumedByAppBar + consumedByRefresh
            }

            RefreshState.RefreshComplete, RefreshState.Refreshing -> {
                return available
            }

            else -> {
                val consumedByRefresh = pullToRefreshState.getOrCreateNestedScrollConnection(overScrollState).onPreScroll(available, source)
                val remaining = available - consumedByRefresh
                val consumedByAppBar = topAppBarScrollBehavior?.nestedScrollConnection?.onPreScroll(remaining, source) ?: Offset.Zero
                return consumedByRefresh + consumedByAppBar
            }
        }
    }

    override fun onPostScroll(consumed: Offset, available: Offset, source: NestedScrollSource): Offset {
        when (pullToRefreshState.refreshState) {
            RefreshState.RefreshComplete, RefreshState.Refreshing -> {
                return available
            }

            else -> {
                val consumedByAppBar =
                    topAppBarScrollBehavior?.nestedScrollConnection?.onPostScroll(consumed, available, source) ?: Offset.Zero
                val remaining = available - consumedByAppBar
                val consumedByRefresh = pullToRefreshState
                    .getOrCreateNestedScrollConnection(overScrollState)
                    .onPostScroll(consumed, remaining, source)
                return consumedByAppBar + consumedByRefresh
            }
        }
    }

    override suspend fun onPreFling(available: Velocity): Velocity {
        if (pullToRefreshState.refreshState != RefreshState.Idle) {
            return available
        }
        return Velocity.Zero
    }

    override suspend fun onPostFling(consumed: Velocity, available: Velocity): Velocity {
        if (pullToRefreshState.refreshState != RefreshState.Idle) {
            // Ensure the indicator cancels and rebounds to zero.
            if (
                pullToRefreshState.refreshState != RefreshState.Refreshing &&
                pullToRefreshState.refreshState != RefreshState.RefreshComplete &&
                !pullToRefreshState.isRefreshing &&
                !pullToRefreshState.isRebounding &&
                pullToRefreshState.dragOffset > 0f &&
                pullToRefreshState.dragOffset < pullToRefreshState.refreshThresholdOffset
            ) {
                try {
                    pullToRefreshState.isRebounding = true
                    pullToRefreshState.animateToSpring(0f)
                } finally {
                    pullToRefreshState.isRebounding = false
                    pullToRefreshState.resetToIdle()
                }
            }
            return available
        }
        return topAppBarScrollBehavior?.nestedScrollConnection?.onPostFling(consumed, available) ?: Velocity.Zero
    }
}

@Composable
private fun RefreshHeader(
    pullToRefreshState: PullToRefreshState,
    circleSize: Dp,
    color: Color,
    refreshTexts: List<String>,
    refreshTextStyle: TextStyle,
    modifier: Modifier = Modifier,
) {
    val hapticFeedback = LocalHapticFeedback.current
    val density = LocalDensity.current

    LaunchedEffect(pullToRefreshState.refreshState) {
        if (pullToRefreshState.refreshState == RefreshState.ThresholdReached) {
            hapticFeedback.performHapticFeedback(HapticFeedbackType.GestureThresholdActivate)
        }
    }

    val refreshText by remember(pullToRefreshState, refreshTexts) {
        derivedStateOf {
            when (pullToRefreshState.refreshState) {
                RefreshState.Idle -> ""

                RefreshState.Pulling -> {
                    if (pullToRefreshState.pullProgress > 0.5) refreshTexts.getOrElse(0) { "" } else ""
                }

                RefreshState.ThresholdReached -> refreshTexts.getOrElse(1) { "" }

                RefreshState.Refreshing -> refreshTexts.getOrElse(2) { "" }

                RefreshState.RefreshComplete -> refreshTexts.getOrElse(3) { "" }
            }
        }
    }

    val refreshTextAlpha by remember(pullToRefreshState) {
        derivedStateOf {
            when (pullToRefreshState.refreshState) {
                RefreshState.Idle -> 0f

                RefreshState.Pulling -> {
                    val progress = pullToRefreshState.pullProgress
                    if (progress > 0.6f) (progress - 0.5f) * 2f else 0f
                }

                RefreshState.ThresholdReached, RefreshState.Refreshing -> 1f

                RefreshState.RefreshComplete -> {
                    (1f - pullToRefreshState.refreshCompleteAnimProgress * 1.95f).coerceAtLeast(0f)
                }
            }
        }
    }

    val indicatorHeight by remember(pullToRefreshState, circleSize, density) {
        derivedStateOf {
            when (pullToRefreshState.refreshState) {
                RefreshState.Idle -> 0.dp

                RefreshState.Pulling -> circleSize * pullToRefreshState.pullProgress

                RefreshState.ThresholdReached -> {
                    val offsetDp = with(density) { (pullToRefreshState.dragOffset - pullToRefreshState.refreshThresholdOffset).toDp() }
                    circleSize + offsetDp
                }

                RefreshState.Refreshing -> circleSize

                RefreshState.RefreshComplete -> circleSize * (1 - pullToRefreshState.refreshCompleteAnimProgress)
            }
        }
    }

    val headerHeight by remember(pullToRefreshState, circleSize, density) {
        derivedStateOf {
            when (pullToRefreshState.refreshState) {
                RefreshState.Idle -> 0.dp

                RefreshState.Pulling -> (circleSize + 36.dp) * pullToRefreshState.pullProgress

                RefreshState.ThresholdReached -> {
                    val offsetDp = with(density) { (pullToRefreshState.dragOffset - pullToRefreshState.refreshThresholdOffset).toDp() }
                    (circleSize + 36.dp) + offsetDp
                }

                RefreshState.Refreshing -> circleSize + 36.dp

                RefreshState.RefreshComplete -> (circleSize + 36.dp) * (1 - pullToRefreshState.refreshCompleteAnimProgress)
            }
        }
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .height(headerHeight),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Top,
    ) {
        RefreshIndicator(
            pullToRefreshState = pullToRefreshState,
            circleSize = circleSize,
            color = color,
            modifier = Modifier.height(indicatorHeight),
        )
        Text(
            text = refreshText,
            style = refreshTextStyle,
            color = color,
            modifier = Modifier.padding(top = 6.dp).graphicsLayer { alpha = refreshTextAlpha },
        )
    }
}

@Composable
private fun RefreshIndicator(
    pullToRefreshState: PullToRefreshState,
    circleSize: Dp,
    color: Color,
    modifier: Modifier = Modifier,
) {
    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter,
    ) {
        // Only create rotation animation when actually refreshing to save resources
        val rotationState = if (pullToRefreshState.refreshState == RefreshState.Refreshing) {
            animateRotation()
        } else {
            null
        }
        Canvas(modifier = Modifier.size(circleSize)) {
            val ringStrokeWidthPx = circleSize.toPx() / 11
            val indicatorRadiusPx = max(size.minDimension / 2, circleSize.toPx() / 3.5f)
            val center = Offset(circleSize.toPx() / 2, circleSize.toPx() / 1.8f)

            when (pullToRefreshState.refreshState) {
                RefreshState.Idle -> return@Canvas

                RefreshState.Pulling -> {
                    val alpha = (pullToRefreshState.pullProgress - 0.2f).coerceAtLeast(0f)
                    drawPullingIndicator(center, indicatorRadiusPx, ringStrokeWidthPx, color, alpha)
                }

                RefreshState.ThresholdReached -> {
                    drawThresholdIndicator(
                        center,
                        indicatorRadiusPx,
                        ringStrokeWidthPx,
                        color,
                        pullToRefreshState.dragOffset,
                        pullToRefreshState.refreshThresholdOffset,
                        pullToRefreshState.maxDragDistancePx,
                    )
                }

                RefreshState.Refreshing -> {
                    drawRefreshingIndicator(
                        center,
                        indicatorRadiusPx,
                        ringStrokeWidthPx,
                        color,
                        rotationState?.value ?: 0f,
                    )
                }

                RefreshState.RefreshComplete -> {
                    drawRefreshCompleteIndicator(
                        center,
                        indicatorRadiusPx,
                        ringStrokeWidthPx,
                        color,
                        pullToRefreshState.refreshCompleteAnimProgress,
                    )
                }
            }
        }
    }
}

@Composable
private fun animateRotation(): State<Float> {
    val infiniteTransition = rememberInfiniteTransition()
    val initialRotation = remember { (0..360).random().toFloat() }
    // COUILoadingView rotates one full turn per 1000 ms with a linear interpolator
    // ((uptimeMillis % 1000) * 360 / 1000 in onDraw).
    return infiniteTransition.animateFloat(
        initialValue = initialRotation,
        targetValue = initialRotation + 360f,
        animationSpec = infiniteRepeatable<Float>(
            animation = tween(1000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart,
        ),
    )
}

private fun DrawScope.drawPullingIndicator(
    center: Offset,
    radius: Float,
    strokeWidth: Float,
    color: Color,
    alpha: Float,
) {
    drawCircle(
        color = color.copy(alpha = alpha),
        radius = radius,
        center = center,
        style = Stroke(strokeWidth, cap = StrokeCap.Round),
    )
}

private fun DrawScope.drawThresholdIndicator(
    center: Offset,
    radius: Float,
    strokeWidth: Float,
    color: Color,
    dragOffset: Float,
    thresholdOffset: Float,
    maxDrag: Float,
) {
    val lineLength = (dragOffset - thresholdOffset).coerceIn(0f, maxDrag - thresholdOffset)
    val topY = center.y
    val bottomY = center.y + lineLength
    drawArc(
        color = color,
        startAngle = 180f,
        sweepAngle = 180f,
        useCenter = false,
        topLeft = Offset(center.x - radius, topY - radius),
        size = Size(radius * 2, radius * 2),
        style = Stroke(width = strokeWidth, cap = StrokeCap.Round),
    )
    drawArc(
        color = color,
        startAngle = 0f,
        sweepAngle = 180f,
        useCenter = false,
        topLeft = Offset(center.x - radius, bottomY - radius),
        size = Size(radius * 2, radius * 2),
        style = Stroke(width = strokeWidth, cap = StrokeCap.Round),
    )
    drawLine(
        color = color,
        start = Offset(center.x - radius, topY),
        end = Offset(center.x - radius, bottomY),
        strokeWidth = strokeWidth,
        cap = StrokeCap.Round,
    )
    drawLine(
        color = color,
        start = Offset(center.x + radius, topY),
        end = Offset(center.x + radius, bottomY),
        strokeWidth = strokeWidth,
        cap = StrokeCap.Round,
    )
}

private fun DrawScope.drawRefreshingIndicator(
    center: Offset,
    radius: Float,
    strokeWidth: Float,
    color: Color,
    rotation: Float,
) {
    drawCircle(
        color = color,
        radius = radius,
        center = center,
        style = Stroke(strokeWidth, cap = StrokeCap.Round),
    )
    val orbitRadius = radius - 2 * strokeWidth
    val angle = rotation * PI / 180.0
    val dotCenter = center + Offset(
        x = (orbitRadius * cos(angle)).toFloat(),
        y = (orbitRadius * sin(angle)).toFloat(),
    )
    drawCircle(color = color, radius = strokeWidth, center = dotCenter)
}

private fun DrawScope.drawRefreshCompleteIndicator(
    center: Offset,
    radius: Float,
    strokeWidth: Float,
    color: Color,
    progress: Float,
) {
    val animatedRadius = radius * (1f - progress).coerceAtLeast(0.9f)
    val alphaColor = color.copy(alpha = (1f - progress - 0.35f).coerceAtLeast(0f))
    val y = center.y - radius - strokeWidth + animatedRadius
    drawCircle(
        color = alphaColor,
        radius = animatedRadius,
        center = Offset(center.x, y),
        style = Stroke(strokeWidth, cap = StrokeCap.Round),
    )
}

private const val MAX_DRAWRATIO = 1 / 6f
private const val THRESHOLD_RADIO = 1 / 4f

internal val LocalPullToRefreshState = staticCompositionLocalOf<PullToRefreshState?> { null }

/** Default values for the [PullToRefresh] component. */
object PullToRefreshDefaults {
    /**
     * The default color of the refresh indicator. [Color.Unspecified] makes [PullToRefresh]
     * fall back to the theme primary color (COUI `couiLoadingViewColor` = couiColorPrimary).
     */
    val color: Color = Color.Unspecified

    /** The default size of the refresh indicator circle (COUI coui_loading_view_refresh_width/height). */
    val circleSize: Dp = 19.dp
    val refreshTexts = listOf(
        "Pull down to refresh",
        "Release to refresh",
        "Refreshing...",
        "Refreshed successfully",
    )
    val refreshTextStyle = TextStyle(
        fontSize = 14.sp,
        fontWeight = FontWeight.Bold,
        color = color,
    )
}
