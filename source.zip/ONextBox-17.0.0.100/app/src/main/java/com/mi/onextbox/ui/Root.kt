package com.mi.onextbox.ui

import androidx.compose.runtime.setValue

import android.os.Build
import androidx.activity.BackEventCompat
import androidx.activity.compose.BackHandler
import androidx.activity.compose.PredictiveBackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.navigationevent.NavigationEventInfo
import androidx.navigationevent.compose.NavigationBackHandler
import androidx.navigationevent.compose.rememberNavigationEventState
import androidx.navigation3.runtime.NavKey
import androidx.navigation3.runtime.entryProvider
import androidx.navigation3.runtime.rememberDecoratedNavEntries
import androidx.navigation3.runtime.rememberNavBackStack
import androidx.navigation3.runtime.rememberSaveableStateHolderNavEntryDecorator
import androidx.navigation3.ui.NavDisplayTransitionEffects
import androidx.savedstate.serialization.SavedStateConfiguration
import androidx.compose.animation.core.EaseInOut
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ScrollState
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.gestures.animateScrollBy
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PagerState
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.ui.layout.boundsInWindow
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.foundation.rememberScrollState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.MutableIntState
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.movableContentOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.snapshotFlow
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.mi.onextbox.ui.layout.BottomNavigationBar
import com.mi.onextbox.ui.layout.LiquidGlassBottomNavigationBar
import com.mi.onextbox.ui.layout.Page
import com.mi.onextbox.ui.layout.rememberChromeBlurBackdrop
import com.mi.onextbox.ui.layout.rememberBottomBarStartupProgress
import com.mi.onextbox.ui.platform.findActivity
import com.mi.onextbox.ui.screens.FeatureMainRoute
import com.mi.onextbox.ui.screens.ToolsMainPage
import com.mi.onextbox.ui.common.ScrollResetEffect
import com.mi.onextbox.ui.common.rememberMainPageScrollState
import com.mi.onextbox.ui.screens.FeatureLaunchOrigin
import com.mi.onextbox.ui.screens.FeaturePageMode
import com.mi.onextbox.ui.screens.FeatureSubRoute
import com.mi.onextbox.ui.screens.FeatureSpotlightPage
import com.mi.onextbox.ui.screens.FeatureSpotlightState
import com.mi.onextbox.ui.screens.LocalFeatureSpotlight
import com.mi.onextbox.ui.settings.AboutMainRoute
import com.mi.onextbox.ui.settings.AboutPageMode
import com.mi.onextbox.ui.settings.AboutSubRoute
import com.mi.onextbox.ui.settings.SoftwareUpdateUiState
import com.mi.onextbox.ui.settings.rememberSoftwareUpdateUiState
import com.mi.onextbox.ui.common.appearanceChangeBottomBar
import com.mi.onextbox.ui.common.AppThemeMode
import com.mi.onextbox.ui.common.AppUiStyle
import com.mi.onextbox.ui.common.AppUiStyleAppTheme
import com.mi.onextbox.ui.common.ColorOs17AppTheme
import com.mi.onextbox.ui.common.LocalAppUiStyle
import com.mi.onextbox.ui.common.isMonet
import com.mi.onextbox.ui.common.AssistantScreenOption
import com.mi.onextbox.ui.common.BottomTab
import com.mi.onextbox.ui.common.FpsMonitorOverlay
import com.mi.onextbox.ui.common.bottomTabs
import com.mi.onextbox.ui.common.rememberHapticClick
import com.kyant.backdrop.backdrops.LayerBackdrop as LiquidLayerBackdrop
import com.kyant.backdrop.backdrops.layerBackdrop as liquidLayerBackdrop
import com.kyant.backdrop.backdrops.rememberLayerBackdrop as rememberLiquidLayerBackdrop
import io.github.suqi8.coui.kmp.basic.NavigationBarDisplayMode
import io.github.suqi8.coui.kmp.basic.NavigationItem
import io.github.suqi8.coui.kmp.basic.Scaffold
import io.github.suqi8.coui.kmp.blur.LayerBackdrop
import io.github.suqi8.coui.kmp.theme.COUITheme
import io.github.suqi8.coui.kmp.theme.ThemeColorSpec
import io.github.suqi8.coui.kmp.theme.ThemeController
import io.github.suqi8.coui.kmp.theme.ThemePaletteStyle
import io.github.suqi8.coui.kmp.utils.COUIPopupUtils.Companion.COUIPopupHost
import androidx.core.view.WindowInsetsControllerCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.serialization.Serializable
import kotlinx.serialization.modules.SerializersModule
import kotlinx.serialization.modules.polymorphic
import kotlinx.serialization.modules.subclass
import kotlin.math.abs
import kotlin.math.roundToInt

@Stable
private class RootMainPagerState(
    val pagerState: PagerState,
    private val coroutineScope: CoroutineScope,
    scrollResetGenerationState: MutableIntState,
) {
    var selectedPage by mutableIntStateOf(pagerState.currentPage)
        private set

    var isNavigating by mutableStateOf(false)
        private set
    var scrollResetGeneration by scrollResetGenerationState
        private set
    private var navigationJob: Job? = null

    fun animateToPage(targetIndex: Int) {
        if (
            targetIndex == selectedPage &&
            targetIndex == pagerState.currentPage &&
            abs(pagerState.currentPageOffsetFraction) < 0.001f
        ) {
            return
        }
        navigationJob?.cancel()
        selectedPage = targetIndex
        isNavigating = true
        val distance = abs(targetIndex - pagerState.currentPage).coerceAtLeast(2)
        val duration = 100 * distance + 100
        val layoutInfo = pagerState.layoutInfo
        val pageSize = layoutInfo.pageSize + layoutInfo.pageSpacing
        val currentDistanceInPages =
            targetIndex - pagerState.currentPage - pagerState.currentPageOffsetFraction
        val scrollPixels = currentDistanceInPages * pageSize
        navigationJob = coroutineScope.launch {
            val myJob = coroutineContext[Job]
            try {
                if (pageSize == 0) {
                    pagerState.scrollToPage(targetIndex)
                } else {
                    pagerState.animateScrollBy(
                        value = scrollPixels,
                        animationSpec = tween(easing = EaseInOut, durationMillis = duration),
                    )
                }
            } finally {
                if (navigationJob == myJob) {
                    if (pagerState.currentPage != targetIndex) {
                        selectedPage = pagerState.currentPage
                    }
                    isNavigating = false
                    scrollResetGeneration += 1
                }
            }
        }
    }

    fun syncPage() {
        if (!isNavigating && selectedPage != pagerState.currentPage) {
            selectedPage = pagerState.currentPage
        }
    }
}

@Composable
private fun rememberRootMainPagerState(pagerState: PagerState): RootMainPagerState {
    val coroutineScope = rememberCoroutineScope()
    val scrollResetGeneration = rememberSaveable { mutableIntStateOf(0) }
    return remember(pagerState, coroutineScope, scrollResetGeneration) {
        RootMainPagerState(pagerState, coroutineScope, scrollResetGeneration)
    }
}

@Composable
private fun MainScreenBackHandler(
    mainPagerState: RootMainPagerState,
    navigator: RootNavigator,
    onTabChange: (Int) -> Unit,
) {
    val isPagerBackHandlerEnabled by remember {
        derivedStateOf {
            navigator.current() is RootRoute.Main &&
                    navigator.backStackSize() == 1 &&
                    mainPagerState.selectedPage != 0
        }
    }
    val mainBackEventState = rememberNavigationEventState(NavigationEventInfo.None)
    NavigationBackHandler(
        state = mainBackEventState,
        isBackEnabled = isPagerBackHandlerEnabled,
        onBackCompleted = {
            mainPagerState.animateToPage(0)
            onTabChange(0)
        },
    )
}

@Serializable
private sealed interface RootRoute : NavKey {
    @Serializable
    data object Main : RootRoute

    @Serializable
    data object FeatureDesktop : RootRoute

    @Serializable
    data object FeatureEnabledFeatures : RootRoute

    @Serializable
    data object FeatureUpdates : RootRoute

    @Serializable
    data object FeatureCoui : RootRoute

    @Serializable
    data object FeatureTools : RootRoute

    @Serializable
    data object FeatureMore : RootRoute

    @Serializable
    data object FeatureDesktopLayout : RootRoute

    @Serializable
    data object FeatureDesktopIcons : RootRoute

    @Serializable
    data object FeatureDesktopRecent : RootRoute

    @Serializable
    data object FeatureDesktopHiddenApps : RootRoute

    @Serializable
    data object FeatureDesktopPages : RootRoute

    @Serializable
    data object FeatureSystemUi : RootRoute

    @Serializable
    data object FeatureSystemUiNative : RootRoute

    @Serializable
    data object FeatureSystemUiBackGesture : RootRoute

    @Serializable
    data object FeatureSystemUiBackGestureArea : RootRoute

    @Serializable
    data object FeatureSystemUiVolume : RootRoute

    @Serializable
    data object FeatureSystemUiDynamicColor : RootRoute

    @Serializable
    data object FeatureSystemUiStatusBar : RootRoute

    @Serializable
    data object FeatureSystemUiStatusBarLayout : RootRoute

    @Serializable
    data object FeatureSystemUiStatusBarNetwork : RootRoute

    @Serializable
    data object FeatureSystemUiStatusBarSpeed : RootRoute

    @Serializable
    data object FeatureSystemUiStatusBarPower : RootRoute

    @Serializable
    data object FeatureSystemUiStatusBarBattery : RootRoute

    @Serializable
    data object FeatureSystemUiStatusBarInteraction : RootRoute


    @Serializable
    data object FeatureSystemUiClock : RootRoute

    @Serializable
    data object FeatureSystemUiIconOrder : RootRoute

    @Serializable
    data object FeatureSystemUiFluidCloud : RootRoute

    @Serializable
    data object FeatureSystemUiFluidCloudMediaBlacklist : RootRoute

    @Serializable
    data object FeatureSystemUiNotificationCenter : RootRoute

    @Serializable
    data object FeatureSystemUiControlCenter : RootRoute

    @Serializable
    data object FeatureSystemUiCornerSettings : RootRoute

    @Serializable
    data object FeatureSystemUiPercentageSettings : RootRoute

    @Serializable
    data object FeatureSystemUiSideVolumePercentageSettings : RootRoute

    @Serializable
    data object FeatureSystemUiSmallWindow : RootRoute

    @Serializable
    data object FeatureSystemUiLockScreen : RootRoute

    @Serializable
    data object FeatureSystemUiNavigationBar : RootRoute

    @Serializable
    data object FeatureNotificationRemoval : RootRoute

    @Serializable
    data object FeatureMobileNetwork : RootRoute

    @Serializable
    data object FeatureAndroidSystem : RootRoute

    @Serializable
    data object FeatureCorePatch : RootRoute

    @Serializable
    data object FeatureSideKey : RootRoute

    @Serializable
    data object FeatureInstaller : RootRoute

    @Serializable
    data object FeatureEsim : RootRoute

    @Serializable
    data object FeatureEsimDiagnostics : RootRoute

    @Serializable
    data object FeatureAppMarket : RootRoute

    @Serializable
    data object FeatureBattery : RootRoute

    @Serializable
    data object FeatureTrafficManagement : RootRoute

    @Serializable
    data object FeaturePhoneManager : RootRoute

    @Serializable
    data object FeatureThemeStore : RootRoute

    @Serializable
    data object FeatureGallery : RootRoute

    @Serializable
    data object FeatureSecurePay : RootRoute

    @Serializable
    data object FeatureGameAssistant : RootRoute

    @Serializable
    data object FeatureOShare : RootRoute

    @Serializable
    data object FeatureSoftwareUpdate : RootRoute

    @Serializable
    data object FeatureKeyboard : RootRoute

    @Serializable
    data object FeaturePictorial : RootRoute

    @Serializable
    data object FeatureBrowser : RootRoute

    @Serializable
    data object FeatureWeather : RootRoute

    @Serializable
    data object FeaturePhotoPicker : RootRoute

    @Serializable
    data object FeatureEngineerMode : RootRoute

    @Serializable
    data object FeatureQuickAppServices : RootRoute

    @Serializable
    data object FeatureFileManager : RootRoute

    @Serializable
    data object FeatureGoogleMessages : RootRoute

    @Serializable
    data object FeatureSystemMessages : RootRoute

    @Serializable
    data object FeatureAppErrors : RootRoute

    @Serializable
    data object FeatureNotificationBatch : RootRoute

    @Serializable
    data class AppErrorDetail(val id: Long) : RootRoute

    @Serializable
    data object FeatureAthena : RootRoute

    @Serializable
    data object FeatureSettings : RootRoute

    @Serializable
    data object FeatureSettingsRegion : RootRoute

    @Serializable
    data object FeatureSettingsAppearance : RootRoute

    @Serializable
    data object FeatureSettingsApps : RootRoute

    @Serializable
    data object FeatureSettingsPermissions : RootRoute

    @Serializable
    data object FeatureSettingsAboutDevice : RootRoute
    @Serializable
    data object FeatureSettingsRealme : RootRoute

    @Serializable
    data object FeatureSecurityPermission : RootRoute

    @Serializable
    data object FeatureTouchSampling : RootRoute

    @Serializable
    data object FeatureWallpapers : RootRoute

    @Serializable
    data object FeatureAod : RootRoute

    @Serializable
    data object FeatureScreenshot : RootRoute

    @Serializable
    data object FeatureScreenRecording : RootRoute

    @Serializable
    data object FeatureCamera : RootRoute

    @Serializable
    data object FeatureTranslation : RootRoute

    @Serializable
    data object FeatureSmartSidebar : RootRoute

    @Serializable
    data object FeatureAppInstaller : RootRoute

    @Serializable
    data object FeaturePackageInstaller : RootRoute

    @Serializable
    data object FeatureAssistant : RootRoute


    @Serializable
    data object AppSettings : RootRoute

    @Serializable
    data object Logs : RootRoute

    @Serializable
    data object DeveloperOptions : RootRoute

    @Serializable
    data object DeviceDetails : RootRoute

    @Serializable
    data object SoftwareUpdate : RootRoute

    @Serializable
    data object SoftwareUpdateSettings : RootRoute

    @Serializable
    data object SoftwareUpdateReleaseNotes : RootRoute

    @Serializable
    data object Contributors : RootRoute

    @Serializable
    data object References : RootRoute
}

private fun FeaturePageMode.toRootRoute(): RootRoute? = when (this) {
    FeaturePageMode.EnabledFeatures -> RootRoute.FeatureEnabledFeatures
    FeaturePageMode.Updates -> RootRoute.FeatureUpdates
    FeaturePageMode.Coui -> RootRoute.FeatureCoui
    FeaturePageMode.Tools -> RootRoute.FeatureTools
    FeaturePageMode.More -> RootRoute.FeatureMore
    FeaturePageMode.Main -> null
    FeaturePageMode.Desktop -> RootRoute.FeatureDesktop
    FeaturePageMode.DesktopLayout -> RootRoute.FeatureDesktopLayout
    FeaturePageMode.DesktopIcons -> RootRoute.FeatureDesktopIcons
    FeaturePageMode.DesktopRecent -> RootRoute.FeatureDesktopRecent
    FeaturePageMode.DesktopHiddenApps -> RootRoute.FeatureDesktopHiddenApps
    FeaturePageMode.DesktopPages -> RootRoute.FeatureDesktopPages
    FeaturePageMode.SystemUi -> RootRoute.FeatureSystemUi
    FeaturePageMode.SystemUiNative -> RootRoute.FeatureSystemUiNative
    FeaturePageMode.SystemUiBackGesture -> RootRoute.FeatureSystemUiBackGesture
    FeaturePageMode.SystemUiBackGestureArea -> RootRoute.FeatureSystemUiBackGestureArea
    FeaturePageMode.SystemUiVolume -> RootRoute.FeatureSystemUiVolume
    FeaturePageMode.SystemUiDynamicColor -> RootRoute.FeatureSystemUiDynamicColor
    FeaturePageMode.SystemUiClock -> RootRoute.FeatureSystemUiClock
    FeaturePageMode.SystemUiStatusBar -> RootRoute.FeatureSystemUiStatusBar
    FeaturePageMode.SystemUiStatusBarLayout -> RootRoute.FeatureSystemUiStatusBarLayout
    FeaturePageMode.SystemUiStatusBarNetwork -> RootRoute.FeatureSystemUiStatusBarNetwork
    FeaturePageMode.SystemUiStatusBarSpeed -> RootRoute.FeatureSystemUiStatusBarSpeed
    FeaturePageMode.SystemUiStatusBarPower -> RootRoute.FeatureSystemUiStatusBarPower
    FeaturePageMode.SystemUiStatusBarBattery -> RootRoute.FeatureSystemUiStatusBarBattery
    FeaturePageMode.SystemUiStatusBarInteraction -> RootRoute.FeatureSystemUiStatusBarInteraction
    FeaturePageMode.SystemUiIconOrder -> RootRoute.FeatureSystemUiIconOrder
    FeaturePageMode.SystemUiFluidCloud -> RootRoute.FeatureSystemUiFluidCloud
    FeaturePageMode.SystemUiFluidCloudMediaBlacklist -> RootRoute.FeatureSystemUiFluidCloudMediaBlacklist
    FeaturePageMode.SystemUiNotificationCenter -> RootRoute.FeatureSystemUiNotificationCenter
    FeaturePageMode.SystemUiControlCenter -> RootRoute.FeatureSystemUiControlCenter
    FeaturePageMode.SystemUiCornerSettings -> RootRoute.FeatureSystemUiCornerSettings
    FeaturePageMode.SystemUiPercentageSettings -> RootRoute.FeatureSystemUiPercentageSettings
    FeaturePageMode.SystemUiSideVolumePercentageSettings -> RootRoute.FeatureSystemUiSideVolumePercentageSettings
    FeaturePageMode.SystemUiSmallWindow -> RootRoute.FeatureSystemUiSmallWindow
    FeaturePageMode.SystemUiLockScreen -> RootRoute.FeatureSystemUiLockScreen
    FeaturePageMode.SystemUiNavigationBar -> RootRoute.FeatureSystemUiNavigationBar
    FeaturePageMode.NotificationRemoval -> RootRoute.FeatureNotificationRemoval
    FeaturePageMode.MobileNetwork -> RootRoute.FeatureMobileNetwork
    FeaturePageMode.AndroidSystem -> RootRoute.FeatureAndroidSystem
    FeaturePageMode.CorePatch -> RootRoute.FeatureCorePatch
    FeaturePageMode.SideKey -> RootRoute.FeatureSideKey
    FeaturePageMode.Installer -> RootRoute.FeatureInstaller
    FeaturePageMode.Esim -> RootRoute.FeatureEsim
    FeaturePageMode.EsimDiagnostics -> RootRoute.FeatureEsimDiagnostics
    FeaturePageMode.AppMarket -> RootRoute.FeatureAppMarket
    FeaturePageMode.Battery -> RootRoute.FeatureBattery
    FeaturePageMode.TrafficManagement -> RootRoute.FeatureTrafficManagement
    FeaturePageMode.PhoneManager -> RootRoute.FeaturePhoneManager
    FeaturePageMode.ThemeStore -> RootRoute.FeatureThemeStore
    FeaturePageMode.Gallery -> RootRoute.FeatureGallery
    FeaturePageMode.SecurePay -> RootRoute.FeatureSecurePay
    FeaturePageMode.GameAssistant -> RootRoute.FeatureGameAssistant
    FeaturePageMode.OShare -> RootRoute.FeatureOShare
    FeaturePageMode.SoftwareUpdate -> RootRoute.FeatureSoftwareUpdate
    FeaturePageMode.Keyboard -> RootRoute.FeatureKeyboard
    FeaturePageMode.Browser -> RootRoute.FeatureBrowser
    FeaturePageMode.Weather -> RootRoute.FeatureWeather
    FeaturePageMode.PhotoPicker -> RootRoute.FeaturePhotoPicker
    FeaturePageMode.EngineerMode -> RootRoute.FeatureEngineerMode
    FeaturePageMode.Pictorial -> RootRoute.FeaturePictorial
    FeaturePageMode.QuickAppServices -> RootRoute.FeatureQuickAppServices
    FeaturePageMode.FileManager -> RootRoute.FeatureFileManager
    FeaturePageMode.GoogleMessages -> RootRoute.FeatureGoogleMessages
    FeaturePageMode.SystemMessages -> RootRoute.FeatureSystemMessages
    FeaturePageMode.AppErrors -> RootRoute.FeatureAppErrors
    FeaturePageMode.NotificationBatch -> RootRoute.FeatureNotificationBatch
    FeaturePageMode.Athena -> RootRoute.FeatureAthena
    FeaturePageMode.Settings -> RootRoute.FeatureSettings
    FeaturePageMode.SettingsRegion -> RootRoute.FeatureSettingsRegion
    FeaturePageMode.SettingsAppearance -> RootRoute.FeatureSettingsAppearance
    FeaturePageMode.SettingsApps -> RootRoute.FeatureSettingsApps
    FeaturePageMode.SettingsPermissions -> RootRoute.FeatureSettingsPermissions
    FeaturePageMode.SettingsAboutDevice -> RootRoute.FeatureSettingsAboutDevice
    FeaturePageMode.SettingsRealme -> RootRoute.FeatureSettingsRealme
    FeaturePageMode.SecurityPermission -> RootRoute.FeatureSecurityPermission
    FeaturePageMode.TouchSampling -> RootRoute.FeatureTouchSampling
    FeaturePageMode.Wallpapers -> RootRoute.FeatureWallpapers
    FeaturePageMode.Aod -> RootRoute.FeatureAod
    FeaturePageMode.Screenshot -> RootRoute.FeatureScreenshot
    FeaturePageMode.ScreenRecording -> RootRoute.FeatureScreenRecording
    FeaturePageMode.Camera -> RootRoute.FeatureCamera
    FeaturePageMode.Translation -> RootRoute.FeatureTranslation
    FeaturePageMode.SmartSidebar -> RootRoute.FeatureSmartSidebar
    FeaturePageMode.AppInstaller -> RootRoute.FeatureAppInstaller
    FeaturePageMode.PackageInstaller -> RootRoute.FeaturePackageInstaller
    FeaturePageMode.Assistant -> RootRoute.FeatureAssistant
}

private fun AboutPageMode.toRootRoute(): RootRoute? = when (this) {
    AboutPageMode.Main -> null
    AboutPageMode.AppSettings -> RootRoute.AppSettings
    AboutPageMode.Logs -> RootRoute.Logs
    AboutPageMode.DeveloperOptions -> RootRoute.DeveloperOptions
    AboutPageMode.Update -> RootRoute.SoftwareUpdate
    AboutPageMode.UpdateSettings -> RootRoute.SoftwareUpdateSettings
    AboutPageMode.UpdateReleaseNotes -> RootRoute.SoftwareUpdateReleaseNotes
    AboutPageMode.Contributors -> RootRoute.Contributors
    AboutPageMode.References -> RootRoute.References
}

@Stable
private data class RootUiState(
    val currentTab: Int,
    val rootGranted: Boolean,
    val blurEffectEnabled: Boolean,
    val featurePageNewStyleEnabled: Boolean,
    val featurePageDynamicBackgroundActive: Boolean,
    val bottomBarStartupProgress: () -> Float,
    val hiddenFeatureSourceModes: Set<FeaturePageMode>,
    val featureExternalIconScales: Map<FeaturePageMode, () -> Float>,
    val popDirectionFollowsSwipeEdge: Boolean,
    val showFpsMonitor: Boolean,
    val liquidGlassBottomBarEnabled: Boolean,
    val bottomBarHideLabels: Boolean,
    val mainPageSwipeEnabled: Boolean,
    val subPageSwipeEnabled: Boolean,
    val appLanguageTag: String,
    val appThemeMode: AppThemeMode,
    val appUiStyle: AppUiStyle,
    val appThemeKeyColor: Long?,
    val appThemePaletteStyle: Int,
    val appThemeColorSpec: Int,
    val permissionMonitorVisible: Boolean,
    val nativeNotifyIconEnabled: Boolean,
    val nativeNotificationBubblesEnabled: Boolean,
    val systemUiInternationalNetworkDisplayEnabled: Boolean,
    val systemUiHideMobileRoamingIndicatorEnabled: Boolean,
    val systemUiInternationalNotificationStyleEnabled: Boolean,
    val systemUiHideQsEditEnabled: Boolean,
    val systemUiHideQsSettingsEnabled: Boolean,
    val systemUiHideQsTopCarrierEnabled: Boolean,
    val systemUiHideQsMoreEnabled: Boolean,
    val systemUiForceNativeClipboardOverlayEnabled: Boolean,
    val settingsForceGoogleEntryEnabled: Boolean,
    val gmsRegionRestrictionBypassEnabled: Boolean,
    val extremeRefresh165Enabled: Boolean,
    val launcherLayoutUnlocked: Boolean,
    val assistantScreenOption: AssistantScreenOption,
    val recentTaskRadiusEnabled: Boolean,
    val recentTaskRadiusDp: Int,
    val aodEnhanceEnabled: Boolean,
    val aodInitDarkBrightness: Int,
    val aodInitBrightBrightness: Int,
    val aodRunningBrightnessMultiplier: Float,
    val aodAllDayUnlockEnabled: Boolean,
    val aodSingleClickBlockEnabled: Boolean,
    val assistantPowerMode: Int,
    val assistantGestureCircleEnabled: Boolean,
    val assistantGestureCircleC17Enabled: Boolean,
    val assistantNativePowerEnabled: Boolean,
    val assistantNativeCircleEnabled: Boolean,
    val visibleTabs: List<BottomTab>,
    val selectedIndex: Int,
    val bottomNavigationHeight: Dp,
    val blurBackdrop: LayerBackdrop?,
    val liquidBackdrop: LiquidLayerBackdrop?,
    val softwareUpdateState: SoftwareUpdateUiState,
)

@Stable
private data class RootActions(
    val onTabChange: (Int) -> Unit,
    val onBlurEffectEnabledChange: (Boolean) -> Unit,
    val onFeaturePageNewStyleEnabledChange: (Boolean) -> Unit,
    val onPopDirectionFollowsSwipeEdgeChange: (Boolean) -> Unit,
    val onShowFpsMonitorChange: (Boolean) -> Unit,
    val onLiquidGlassBottomBarEnabledChange: (Boolean) -> Unit,
    val onBottomBarHideLabelsChange: (Boolean) -> Unit,
    val onMainPageSwipeEnabledChange: (Boolean) -> Unit,
    val onSubPageSwipeEnabledChange: (Boolean) -> Unit,
    val onAppLanguageChange: (String) -> Unit,
    val onAppThemeModeChange: (AppThemeMode) -> Unit,
    val onAppUiStyleChange: (AppUiStyle) -> Unit,
    val onAppThemeKeyColorChange: (Long?) -> Unit,
    val onAppThemePaletteStyleChange: (Int) -> Unit,
    val onAppThemeColorSpecChange: (Int) -> Unit,
    val onPermissionMonitorVisibleChange: (Boolean) -> Unit,
    val onNativeNotifyIconEnabledChange: (Boolean) -> Unit,
    val onNativeNotificationBubblesEnabledChange: (Boolean) -> Unit,
    val onSystemUiInternationalNetworkDisplayEnabledChange: (Boolean) -> Unit,
    val onSystemUiHideMobileRoamingIndicatorEnabledChange: (Boolean) -> Unit,
    val onSystemUiInternationalNotificationStyleEnabledChange: (Boolean) -> Unit,
    val onSystemUiHideQsEditEnabledChange: (Boolean) -> Unit,
    val onSystemUiHideQsSettingsEnabledChange: (Boolean) -> Unit,
    val onSystemUiHideQsTopCarrierEnabledChange: (Boolean) -> Unit,
    val onSystemUiHideQsMoreEnabledChange: (Boolean) -> Unit,
    val onSystemUiForceNativeClipboardOverlayEnabledChange: (Boolean) -> Unit,
    val onSettingsForceGoogleEntryEnabledChange: (Boolean) -> Unit,
    val onGmsRegionRestrictionBypassEnabledChange: (Boolean) -> Unit,
    val onExtremeRefresh165EnabledChange: (Boolean) -> Unit,
    val onLauncherLayoutUnlockedChange: (Boolean) -> Unit,
    val onAssistantScreenOptionChange: (AssistantScreenOption) -> Unit,
    val onRecentTaskRadiusEnabledChange: (Boolean) -> Unit,
    val onRecentTaskRadiusDpChange: (Int) -> Unit,
    val onAodEnhanceEnabledChange: (Boolean) -> Unit,
    val onAodInitDarkBrightnessChange: (Int) -> Unit,
    val onAodInitBrightBrightnessChange: (Int) -> Unit,
    val onAodRunningBrightnessMultiplierChange: (Float) -> Unit,
    val onAodAllDayUnlockEnabledChange: (Boolean) -> Unit,
    val onAodSingleClickBlockEnabledChange: (Boolean) -> Unit,
    val onAssistantPowerModeChange: (Int) -> Unit,
    val onAssistantGestureCircleEnabledChange: (Boolean) -> Unit,
    val onAssistantGestureCircleC17EnabledChange: (Boolean) -> Unit,
    val onAssistantNativePowerEnabledChange: (Boolean) -> Unit,
    val onAssistantNativeCircleEnabledChange: (Boolean) -> Unit,
    val onBottomNavigationHeightChange: (Int) -> Unit,
    val onBottomChromeBoundsChange: (Boolean, Rect) -> Unit,
    val onHapticClick: () -> Unit,
    val popRootRoute: () -> Unit,
    val popToMainRoute: () -> Unit,
    val openFeatureSubPage: (FeaturePageMode) -> Unit,
    val openAppErrorDetail: (Long) -> Unit,
    val openFeatureSubPageFromMain: (FeaturePageMode, FeatureLaunchOrigin?) -> Unit,
    val openAboutSubPage: (AboutPageMode) -> Unit,
    val requestAboutAutoCheckUpdate: () -> Unit,
)

private val LocalRootUiState = compositionLocalOf<RootUiState> {
    error("No RootUiState provided")
}

private val LocalRootActions = staticCompositionLocalOf<RootActions> {
    error("No RootActions provided")
}

private val LocalRootNavigator = staticCompositionLocalOf<RootNavigator> {
    error("No RootNavigator provided")
}

private val LocalMainPagerState = staticCompositionLocalOf<RootMainPagerState> {
    error("No RootMainPagerState provided")
}

@Composable
private fun RootFeatureEntry(
    pageMode: FeaturePageMode,
    transitionScrollState: ScrollState,
) {
    val ui = LocalRootUiState.current
    val actions = LocalRootActions.current
    // NavDisplay keeps both entries composed during predictive back. Each entry must
    // own its capture layer; sharing the main-page backdrop lets the two scenes
    // overwrite one another and leaves rectangular holes in the toolbar blur.
    val entryBlurBackdrop = rememberChromeBlurBackdrop(ui.blurEffectEnabled)
    FeatureSpotlightPage(pageMode, ui.bottomNavigationHeight) {
    FeatureSubRoute(
        modifier = Modifier.fillMaxSize(),
        pageMode = pageMode,
        permissionMonitorVisible = ui.permissionMonitorVisible,
        onPermissionMonitorVisibleChange = {},
        nativeNotifyIconEnabled = ui.nativeNotifyIconEnabled,
        onNativeNotifyIconEnabledChange = {},
        nativeNotificationBubblesEnabled = ui.nativeNotificationBubblesEnabled,
        onNativeNotificationBubblesEnabledChange = {},
        systemUiInternationalNetworkDisplayEnabled =
            ui.systemUiInternationalNetworkDisplayEnabled,
        onSystemUiInternationalNetworkDisplayEnabledChange =
            {},
        systemUiHideMobileRoamingIndicatorEnabled =
            ui.systemUiHideMobileRoamingIndicatorEnabled,
        onSystemUiHideMobileRoamingIndicatorEnabledChange =
            {},
        systemUiInternationalNotificationStyleEnabled =
            ui.systemUiInternationalNotificationStyleEnabled,
        onSystemUiInternationalNotificationStyleEnabledChange =
            {},
        systemUiHideQsEditEnabled = ui.systemUiHideQsEditEnabled,
        onSystemUiHideQsEditEnabledChange = {},
        systemUiHideQsSettingsEnabled = ui.systemUiHideQsSettingsEnabled,
        onSystemUiHideQsSettingsEnabledChange = {},
        systemUiHideQsTopCarrierEnabled = ui.systemUiHideQsTopCarrierEnabled,
        onSystemUiHideQsTopCarrierEnabledChange = {},
        systemUiHideQsMoreEnabled = ui.systemUiHideQsMoreEnabled,
        onSystemUiHideQsMoreEnabledChange = {},
        systemUiForceNativeClipboardOverlayEnabled = ui.systemUiForceNativeClipboardOverlayEnabled,
        onSystemUiForceNativeClipboardOverlayEnabledChange = {},
        settingsForceGoogleEntryEnabled = ui.settingsForceGoogleEntryEnabled,
        onSettingsForceGoogleEntryEnabledChange = {},
        gmsRegionRestrictionBypassEnabled = ui.gmsRegionRestrictionBypassEnabled,
        onGmsRegionRestrictionBypassEnabledChange = {},
        extremeRefresh165Enabled = ui.extremeRefresh165Enabled,
        onExtremeRefresh165EnabledChange = {},
        launcherLayoutUnlocked = ui.launcherLayoutUnlocked,
        onLauncherLayoutUnlockedChange = {},
        assistantScreenOption = ui.assistantScreenOption,
        onAssistantScreenOptionChange = {},
        recentTaskRadiusEnabled = ui.recentTaskRadiusEnabled,
        onRecentTaskRadiusEnabledChange = {},
        recentTaskRadiusDp = ui.recentTaskRadiusDp,
        onRecentTaskRadiusDpChange = {},
        aodEnhanceEnabled = ui.aodEnhanceEnabled,
        onAodEnhanceEnabledChange = {},
        aodInitDarkBrightness = ui.aodInitDarkBrightness,
        onAodInitDarkBrightnessChange = {},
        aodInitBrightBrightness = ui.aodInitBrightBrightness,
        onAodInitBrightBrightnessChange = {},
        aodRunningBrightnessMultiplier = ui.aodRunningBrightnessMultiplier,
        onAodRunningBrightnessMultiplierChange = {},
        aodAllDayUnlockEnabled = ui.aodAllDayUnlockEnabled,
        onAodAllDayUnlockEnabledChange = {},
        aodSingleClickBlockEnabled = ui.aodSingleClickBlockEnabled,
        onAodSingleClickBlockEnabledChange = {},
        assistantPowerMode = ui.assistantPowerMode,
        onAssistantPowerModeChange = {},
        assistantGestureCircleEnabled = ui.assistantGestureCircleEnabled,
        onAssistantGestureCircleEnabledChange = {},
        assistantGestureCircleC17Enabled = ui.assistantGestureCircleC17Enabled,
        onAssistantGestureCircleC17EnabledChange =
            {},
        assistantNativePowerEnabled = ui.assistantNativePowerEnabled,
        onAssistantNativePowerEnabledChange = {},
        assistantNativeCircleEnabled = ui.assistantNativeCircleEnabled,
        onAssistantNativeCircleEnabledChange = {},
        subPageBottomExtension = ui.bottomNavigationHeight,
        blurBackdrop = entryBlurBackdrop,
        transitionScrollState = transitionScrollState,
        onBack = actions.popRootRoute,
        onOpenSubPage = actions.openFeatureSubPage,
        onOpenAppErrorDetail = {},
    )
    }
}

@Composable
private fun RootBottomChrome(visible: Boolean, liquidOnly: Boolean) {
    val ui = LocalRootUiState.current
    val actions = LocalRootActions.current
    val mainPagerState = LocalMainPagerState.current
    val liquidBackdrop = ui.liquidBackdrop
    val liquidGlassActive = ui.liquidGlassBottomBarEnabled && liquidBackdrop != null
    val liquidGlassVisible = visible && liquidOnly && liquidGlassActive
    AnimatedVisibility(
        visible = liquidGlassVisible,
        modifier = Modifier.appearanceChangeBottomBar(),
        enter = slideInVertically(initialOffsetY = { it }),
        exit = slideOutVertically(targetOffsetY = { it }),
    ) {
        liquidBackdrop?.let { backdrop ->
            LiquidGlassBottomNavigationBar(
                hideLabels = ui.bottomBarHideLabels,
                startupRevealProgress = ui.bottomBarStartupProgress,
                tabs = ui.visibleTabs,
                selectedIndex = ui.selectedIndex,
                pagerState = mainPagerState.pagerState,
                backdrop = backdrop,
                onCapsuleBoundsChanged = { actions.onBottomChromeBoundsChange(true, it) },
                onTabSelected = { index ->
                    actions.onHapticClick()
                    actions.popToMainRoute()
                    mainPagerState.animateToPage(index)
                    actions.onTabChange(ui.visibleTabs[index].screenIndex)
                },
                modifier = Modifier
                    .onGloballyPositioned { coordinates ->
                        actions.onBottomNavigationHeightChange(coordinates.size.height)
                    },
            )
        }
    }
    AnimatedVisibility(
        visible = visible && !liquidOnly && !liquidGlassActive,
        modifier = Modifier.appearanceChangeBottomBar(),
        enter = fadeIn() + expandVertically(),
        exit = fadeOut() + shrinkVertically(),
    ) {
        AnimatedVisibility(
            visible = true,
            enter = fadeIn() + expandVertically(expandFrom = Alignment.Top),
            exit = fadeOut() + shrinkVertically(shrinkTowards = Alignment.Top),
        ) {
            Box(
                modifier = Modifier.fillMaxWidth(),
            ) {
                DisposableEffect(Unit) {
                    onDispose { actions.onBottomChromeBoundsChange(false, Rect.Zero) }
                }
                BottomNavigationBar(
                    hideLabels = ui.bottomBarHideLabels,
                    startupRevealProgress = ui.bottomBarStartupProgress,
                    items = ui.visibleTabs.mapIndexed { index, tab ->
                        NavigationItem(
                            label = stringResource(tab.titleRes),
                            icon = if (index == ui.selectedIndex) tab.selectedIcon else tab.unselectedIcon,
                        )
                    },
                    selectedIndex = ui.selectedIndex,
                    onItemSelected = { index ->
                        actions.onHapticClick()
                        actions.popToMainRoute()
                        mainPagerState.animateToPage(index)
                        actions.onTabChange(ui.visibleTabs[index].screenIndex)
                    },
                    color = Color.Transparent,
                    showDivider = false,
                    mode = NavigationBarDisplayMode.IconAndText,
                    selectedIcons = ui.visibleTabs.map { it.selectedIcon },
                    unselectedIcons = ui.visibleTabs.map { it.unselectedIcon },
                    modifier = Modifier
                        .onGloballyPositioned { coordinates ->
                            actions.onBottomNavigationHeightChange(coordinates.size.height)
                            actions.onBottomChromeBoundsChange(false, coordinates.boundsInWindow())
                        },
                )
            }
        }
    }
}

@Composable
private fun RootAboutEntry(pageMode: AboutPageMode) {
    val ui = LocalRootUiState.current
    val actions = LocalRootActions.current
    val entryBlurBackdrop = rememberChromeBlurBackdrop(ui.blurEffectEnabled)
    AboutSubRoute(
        modifier = Modifier.fillMaxSize(),
        pageMode = pageMode,
        softwareUpdateState = ui.softwareUpdateState,
        blurEffectEnabled = ui.blurEffectEnabled,
        onBlurEffectEnabledChange = actions.onBlurEffectEnabledChange,
        featurePageNewStyleEnabled = ui.featurePageNewStyleEnabled,
        onFeaturePageNewStyleEnabledChange = actions.onFeaturePageNewStyleEnabledChange,
        popDirectionFollowsSwipeEdge = ui.popDirectionFollowsSwipeEdge,
        onPopDirectionFollowsSwipeEdgeChange = actions.onPopDirectionFollowsSwipeEdgeChange,
        showFpsMonitor = ui.showFpsMonitor,
        onShowFpsMonitorChange = actions.onShowFpsMonitorChange,
        liquidGlassBottomBarEnabled = ui.liquidGlassBottomBarEnabled,
        onLiquidGlassBottomBarEnabledChange = actions.onLiquidGlassBottomBarEnabledChange,
        bottomBarHideLabels = ui.bottomBarHideLabels,
        mainPageSwipeEnabled = ui.mainPageSwipeEnabled,
        subPageSwipeEnabled = ui.subPageSwipeEnabled,
        onBottomBarHideLabelsChange = actions.onBottomBarHideLabelsChange,
        onMainPageSwipeEnabledChange = actions.onMainPageSwipeEnabledChange,
        onSubPageSwipeEnabledChange = actions.onSubPageSwipeEnabledChange,
        appLanguageTag = ui.appLanguageTag,
        onAppLanguageChange = actions.onAppLanguageChange,
        appThemeMode = ui.appThemeMode,
        onAppThemeModeChange = actions.onAppThemeModeChange,
        appUiStyle = ui.appUiStyle,
        onAppUiStyleChange = actions.onAppUiStyleChange,
        appThemeKeyColor = ui.appThemeKeyColor,
        onAppThemeKeyColorChange = actions.onAppThemeKeyColorChange,
        appThemePaletteStyle = ui.appThemePaletteStyle,
        onAppThemePaletteStyleChange = actions.onAppThemePaletteStyleChange,
        appThemeColorSpec = ui.appThemeColorSpec,
        onAppThemeColorSpecChange = actions.onAppThemeColorSpecChange,
        bottomContentPadding = ui.bottomNavigationHeight,
        subPageBottomExtension = ui.bottomNavigationHeight,
        blurBackdrop = entryBlurBackdrop,
        onBack = actions.popRootRoute,
        onOpenDeveloperOptions = { actions.openAboutSubPage(AboutPageMode.DeveloperOptions) },
        onOpenUpdateSettings = { actions.openAboutSubPage(AboutPageMode.UpdateSettings) },
        onOpenUpdateReleaseNotes = { actions.openAboutSubPage(AboutPageMode.UpdateReleaseNotes) },
        onOpenFeatureUpdates = { actions.openFeatureSubPage(FeaturePageMode.Updates) },
    )
}

@Composable
fun Root(
    bottomBarStartupReady: Boolean = true,
    animateBottomBarStartup: Boolean = false,
    openSoftwareUpdateRequest: Int = 0,
    currentTab: Int,
    onTabChange: (Int) -> Unit,
    rootGranted: Boolean,
    blurEffectEnabled: Boolean,
    onBlurEffectEnabledChange: (Boolean) -> Unit,
    featurePageNewStyleEnabled: Boolean,
    onFeaturePageNewStyleEnabledChange: (Boolean) -> Unit,
    popDirectionFollowsSwipeEdge: Boolean,
    onPopDirectionFollowsSwipeEdgeChange: (Boolean) -> Unit,
    showFpsMonitor: Boolean,
    onShowFpsMonitorChange: (Boolean) -> Unit,
    liquidGlassBottomBarEnabled: Boolean,
    onLiquidGlassBottomBarEnabledChange: (Boolean) -> Unit,
    bottomBarHideLabels: Boolean,
    mainPageSwipeEnabled: Boolean,
    subPageSwipeEnabled: Boolean,
    onBottomBarHideLabelsChange: (Boolean) -> Unit,
    onMainPageSwipeEnabledChange: (Boolean) -> Unit,
    onSubPageSwipeEnabledChange: (Boolean) -> Unit,
    appLanguageTag: String,
    onAppLanguageChange: (String) -> Unit,
    appThemeMode: AppThemeMode,
    onAppThemeModeChange: (AppThemeMode) -> Unit,
    appUiStyle: AppUiStyle,
    onAppUiStyleChange: (AppUiStyle) -> Unit,
    appThemeKeyColor: Long?,
    onAppThemeKeyColorChange: (Long?) -> Unit,
    appThemePaletteStyle: Int,
    onAppThemePaletteStyleChange: (Int) -> Unit,
    appThemeColorSpec: Int,
    onAppThemeColorSpecChange: (Int) -> Unit,
    permissionMonitorVisible: Boolean,
    onPermissionMonitorVisibleChange: (Boolean) -> Unit,
    nativeNotifyIconEnabled: Boolean,
    onNativeNotifyIconEnabledChange: (Boolean) -> Unit,
    nativeNotificationBubblesEnabled: Boolean,
    onNativeNotificationBubblesEnabledChange: (Boolean) -> Unit,
    systemUiInternationalNetworkDisplayEnabled: Boolean,
    onSystemUiInternationalNetworkDisplayEnabledChange: (Boolean) -> Unit,
    systemUiHideMobileRoamingIndicatorEnabled: Boolean,
    onSystemUiHideMobileRoamingIndicatorEnabledChange: (Boolean) -> Unit,
    systemUiInternationalNotificationStyleEnabled: Boolean,
    onSystemUiInternationalNotificationStyleEnabledChange: (Boolean) -> Unit,
    systemUiHideQsEditEnabled: Boolean,
    onSystemUiHideQsEditEnabledChange: (Boolean) -> Unit,
    systemUiHideQsSettingsEnabled: Boolean,
    onSystemUiHideQsSettingsEnabledChange: (Boolean) -> Unit,
    systemUiHideQsTopCarrierEnabled: Boolean,
    onSystemUiHideQsTopCarrierEnabledChange: (Boolean) -> Unit,
    systemUiHideQsMoreEnabled: Boolean,
    onSystemUiHideQsMoreEnabledChange: (Boolean) -> Unit,
    systemUiForceNativeClipboardOverlayEnabled: Boolean,
    onSystemUiForceNativeClipboardOverlayEnabledChange: (Boolean) -> Unit,
    settingsForceGoogleEntryEnabled: Boolean,
    onSettingsForceGoogleEntryEnabledChange: (Boolean) -> Unit,
    gmsRegionRestrictionBypassEnabled: Boolean,
    onGmsRegionRestrictionBypassEnabledChange: (Boolean) -> Unit,
    extremeRefresh165Enabled: Boolean,
    onExtremeRefresh165EnabledChange: (Boolean) -> Unit,
    launcherLayoutUnlocked: Boolean,
    onLauncherLayoutUnlockedChange: (Boolean) -> Unit,
    assistantScreenOption: AssistantScreenOption,
    onAssistantScreenOptionChange: (AssistantScreenOption) -> Unit,
    recentTaskRadiusEnabled: Boolean,
    onRecentTaskRadiusEnabledChange: (Boolean) -> Unit,
    recentTaskRadiusDp: Int,
    onRecentTaskRadiusDpChange: (Int) -> Unit,
    aodEnhanceEnabled: Boolean,
    onAodEnhanceEnabledChange: (Boolean) -> Unit,
    aodInitDarkBrightness: Int,
    onAodInitDarkBrightnessChange: (Int) -> Unit,
    aodInitBrightBrightness: Int,
    onAodInitBrightBrightnessChange: (Int) -> Unit,
    aodRunningBrightnessMultiplier: Float,
    onAodRunningBrightnessMultiplierChange: (Float) -> Unit,
    aodAllDayUnlockEnabled: Boolean,
    onAodAllDayUnlockEnabledChange: (Boolean) -> Unit,
    aodSingleClickBlockEnabled: Boolean,
    onAodSingleClickBlockEnabledChange: (Boolean) -> Unit,
    assistantPowerMode: Int,
    onAssistantPowerModeChange: (Int) -> Unit,
    assistantGestureCircleEnabled: Boolean,
    onAssistantGestureCircleEnabledChange: (Boolean) -> Unit,
    assistantGestureCircleC17Enabled: Boolean,
    onAssistantGestureCircleC17EnabledChange: (Boolean) -> Unit,
    assistantNativePowerEnabled: Boolean,
    onAssistantNativePowerEnabledChange: (Boolean) -> Unit,
    assistantNativeCircleEnabled: Boolean,
    onAssistantNativeCircleEnabledChange: (Boolean) -> Unit,
) {
    val bottomBarStartupProgress = rememberBottomBarStartupProgress(
        ready = bottomBarStartupReady,
        animate = animateBottomBarStartup,
    )
    val systemInDarkTheme = isSystemInDarkTheme()
    val resolvedKeyColor = com.mi.onextbox.ui.common.rememberMonetSeedColor(
        enabled = appThemeMode.isMonet,
        selectedColor = appThemeKeyColor,
    )
    val themeController = remember(appThemeMode, resolvedKeyColor, appThemePaletteStyle, appThemeColorSpec) {
        val paletteStyle = ThemePaletteStyle.entries.getOrNull(appThemePaletteStyle)
            ?: ThemePaletteStyle.TonalSpot
        val colorSpec = ThemeColorSpec.entries.getOrNull(appThemeColorSpec)
            ?: ThemeColorSpec.Spec2021
        ThemeController(
            colorSchemeMode = appThemeMode.toColorSchemeMode(),
            keyColor = resolvedKeyColor,
            paletteStyle = paletteStyle,
            colorSpec = colorSpec,
        )
    }
    val monet2026Dark = when (appThemeMode) {
        AppThemeMode.MonetDark -> true
        AppThemeMode.MonetLight -> false
        else -> systemInDarkTheme
    }
    val monet2026Colors = remember(appThemeMode, appThemeColorSpec, resolvedKeyColor, monet2026Dark) {
        if (appThemeMode.isMonet && appThemeColorSpec == com.mi.onextbox.ui.common.CouiColorSpec.Spec2026.ordinal && resolvedKeyColor != null) {
            com.mi.onextbox.ui.common.coui2026Colors(resolvedKeyColor, monet2026Dark)
        } else null
    }
    COUITheme(controller = themeController) {
        ColorOs17AppTheme(nativeAccent = !appThemeMode.isMonet, monetColors = monet2026Colors) {
        CompositionLocalProvider(
            LocalAppUiStyle provides appUiStyle,
        ) {
            AppUiStyleAppTheme(style = appUiStyle, mode = appThemeMode, keyColor = appThemeKeyColor,
                paletteStyle = appThemePaletteStyle, colorSpec = appThemeColorSpec) {
        val (backgroundStyle, _) = com.mi.onextbox.ui.screens.rememberFeatureBackgroundSelection()
        val colors = COUITheme.colorScheme
        val blurBackdrop = rememberChromeBlurBackdrop(blurEffectEnabled)
        val liquidBottomBarSupported = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU
        val liquidBackdrop = if (liquidBottomBarSupported && liquidGlassBottomBarEnabled) {
            rememberLiquidLayerBackdrop()
        } else {
            null
        }
        val context = LocalContext.current
        val activity = context.findActivity()
        val statusBarDarkIcons = colors.surface.luminance() > 0.5f
        val navigationBarSurface = if (blurBackdrop != null) colors.surface else colors.background
        val navigationBarDarkIcons = navigationBarSurface.luminance() > 0.5f
        DisposableEffect(activity, statusBarDarkIcons, navigationBarDarkIcons) {
            activity?.window?.let { window ->
                WindowInsetsControllerCompat(window, window.decorView).apply {
                    isAppearanceLightStatusBars = statusBarDarkIcons
                    isAppearanceLightNavigationBars = navigationBarDarkIcons
                }
            }
            onDispose {}
        }
        val hapticClick = rememberHapticClick()
        val featureSpotlight = remember { FeatureSpotlightState() }
        val visibleTabs = bottomTabs
        // Keep stable tab IDs; retired Tools/Refresh Rate selections return to Features.
        val selectedPagerIndex = visibleTabs.indexOfFirst {
            it.screenIndex == if (currentTab == 4) 1 else currentTab
        }.coerceAtLeast(0)
        val pagerState = rememberPagerState(
            initialPage = selectedPagerIndex,
            pageCount = { visibleTabs.size },
        )
        val mainPagerState = rememberRootMainPagerState(pagerState)
        LaunchedEffect(mainPagerState.pagerState.currentPage) {
            mainPagerState.syncPage()
            if (pagerState.isScrollInProgress && !mainPagerState.isNavigating) onTabChange(visibleTabs[pagerState.currentPage].screenIndex)
        }
        LaunchedEffect(selectedPagerIndex) {
            if (mainPagerState.selectedPage != selectedPagerIndex) {
                mainPagerState.animateToPage(selectedPagerIndex)
            }
        }
        LaunchedEffect(currentTab) {
            if (currentTab == 4) onTabChange(1)
        }
        val selectedIndex = mainPagerState.selectedPage
            .coerceIn(0, (visibleTabs.size - 1).coerceAtLeast(0))
        var aboutAutoCheckUpdateRequest by remember { mutableIntStateOf(0) }
        val serializersModule = remember {
            SerializersModule {
                polymorphic(NavKey::class) {
                    subclass(RootRoute.Main::class)
                    subclass(RootRoute.FeatureDesktop::class)
                    subclass(RootRoute.FeatureEnabledFeatures::class)
                    subclass(RootRoute.FeatureUpdates::class)
                    subclass(RootRoute.FeatureCoui::class)
                    subclass(RootRoute.FeatureTools::class)
                    subclass(RootRoute.FeatureMore::class)
                    subclass(RootRoute.FeatureDesktopLayout::class)
                    subclass(RootRoute.FeatureDesktopIcons::class)
                    subclass(RootRoute.FeatureDesktopRecent::class)
                    subclass(RootRoute.FeatureDesktopHiddenApps::class)
                    subclass(RootRoute.FeatureDesktopPages::class)
                    subclass(RootRoute.FeatureSystemUi::class)
                    subclass(RootRoute.FeatureSystemUiNative::class)
                    subclass(RootRoute.FeatureSystemUiBackGesture::class)
                    subclass(RootRoute.FeatureSystemUiBackGestureArea::class)
                    subclass(RootRoute.FeatureSystemUiVolume::class)
                    subclass(RootRoute.FeatureSystemUiDynamicColor::class)
                    subclass(RootRoute.FeatureSystemUiClock::class)
                    subclass(RootRoute.FeatureSystemUiStatusBar::class)
                    subclass(RootRoute.FeatureSystemUiStatusBarLayout::class)
                    subclass(RootRoute.FeatureSystemUiStatusBarNetwork::class)
                    subclass(RootRoute.FeatureSystemUiStatusBarSpeed::class)
                    subclass(RootRoute.FeatureSystemUiStatusBarPower::class)
                    subclass(RootRoute.FeatureSystemUiStatusBarBattery::class)
                    subclass(RootRoute.FeatureSystemUiStatusBarInteraction::class)
                    subclass(RootRoute.FeatureSystemUiIconOrder::class)
                    subclass(RootRoute.FeatureSystemUiFluidCloud::class)
                    subclass(RootRoute.FeatureSystemUiFluidCloudMediaBlacklist::class)
                    subclass(RootRoute.FeatureSystemUiNotificationCenter::class)
                    subclass(RootRoute.FeatureSystemUiControlCenter::class)
                    subclass(RootRoute.FeatureSystemUiCornerSettings::class)
                    subclass(RootRoute.FeatureSystemUiPercentageSettings::class)
                    subclass(RootRoute.FeatureSystemUiSideVolumePercentageSettings::class)
                    subclass(RootRoute.FeatureSystemUiSmallWindow::class)
                    subclass(RootRoute.FeatureSystemUiLockScreen::class)
                    subclass(RootRoute.FeatureSystemUiNavigationBar::class)
                    subclass(RootRoute.FeatureNotificationRemoval::class)
                    subclass(RootRoute.FeatureMobileNetwork::class)
                    subclass(RootRoute.FeatureAndroidSystem::class)
                    subclass(RootRoute.FeatureCorePatch::class)
                    subclass(RootRoute.FeatureSideKey::class)
                    subclass(RootRoute.FeatureInstaller::class)
                    subclass(RootRoute.FeatureEsim::class)
                    subclass(RootRoute.FeatureEsimDiagnostics::class)
                    subclass(RootRoute.FeatureAppMarket::class)
                    subclass(RootRoute.FeatureBattery::class)
                    subclass(RootRoute.FeatureTrafficManagement::class)
                    subclass(RootRoute.FeaturePhoneManager::class)
                    subclass(RootRoute.FeatureThemeStore::class)
                    subclass(RootRoute.FeatureGallery::class)
                    subclass(RootRoute.FeatureSecurePay::class)
                    subclass(RootRoute.FeatureGameAssistant::class)
                    subclass(RootRoute.FeatureOShare::class)
                    subclass(RootRoute.FeatureSoftwareUpdate::class)
                    subclass(RootRoute.FeatureKeyboard::class)
                    subclass(RootRoute.FeaturePictorial::class)
                    subclass(RootRoute.FeatureBrowser::class)
                    subclass(RootRoute.FeatureWeather::class)
                    subclass(RootRoute.FeaturePhotoPicker::class)
                    subclass(RootRoute.FeatureEngineerMode::class)
                    subclass(RootRoute.FeatureQuickAppServices::class)
                    subclass(RootRoute.FeatureFileManager::class)
                    subclass(RootRoute.FeatureGoogleMessages::class)
                    subclass(RootRoute.FeatureSystemMessages::class)
                    subclass(RootRoute.FeatureAppErrors::class)
                    subclass(RootRoute.FeatureNotificationBatch::class)
                    subclass(RootRoute.AppErrorDetail::class)
                    subclass(RootRoute.FeatureAthena::class)
                    subclass(RootRoute.FeatureSettings::class)
                    subclass(RootRoute.FeatureSettingsRegion::class)
                    subclass(RootRoute.FeatureSettingsAppearance::class)
                    subclass(RootRoute.FeatureSettingsApps::class)
                    subclass(RootRoute.FeatureSettingsPermissions::class)
                    subclass(RootRoute.FeatureSettingsAboutDevice::class)
                    subclass(RootRoute.FeatureSettingsRealme::class)
                    subclass(RootRoute.FeatureSecurityPermission::class)
                    subclass(RootRoute.FeatureTouchSampling::class)
                    subclass(RootRoute.FeatureWallpapers::class)
                    subclass(RootRoute.FeatureAod::class)
                    subclass(RootRoute.FeatureScreenshot::class)
                    subclass(RootRoute.FeatureScreenRecording::class)
                    subclass(RootRoute.FeatureCamera::class)
                    subclass(RootRoute.FeatureTranslation::class)
                    subclass(RootRoute.FeatureSmartSidebar::class)
                    subclass(RootRoute.FeatureAppInstaller::class)
                    subclass(RootRoute.FeaturePackageInstaller::class)
                    subclass(RootRoute.FeatureAssistant::class)
                    subclass(RootRoute.AppSettings::class)
                    subclass(RootRoute.Logs::class)
                    subclass(RootRoute.DeveloperOptions::class)
                    subclass(RootRoute.DeviceDetails::class)
                    subclass(RootRoute.SoftwareUpdate::class)
                    subclass(RootRoute.SoftwareUpdateSettings::class)
                    subclass(RootRoute.SoftwareUpdateReleaseNotes::class)
                    subclass(RootRoute.Contributors::class)
                    subclass(RootRoute.References::class)
                }
            }
        }
        val savedStateConfig = remember(serializersModule) {
            SavedStateConfiguration {
                this.serializersModule = serializersModule
            }
        }
        val rootBackStack = rememberNavBackStack(
            configuration = savedStateConfig,
            RootRoute.Main,
        )
        val navigator = remember(rootBackStack) { RootNavigator(rootBackStack) }
        val featureWorkspaceScaleProgress = remember { Animatable(0f) }
        val featureWorkspaceAlphaProgress = remember { Animatable(0f) }
        val featureWorkspaceBlurProgress = remember { Animatable(0f) }
        val featureQueuePressScales = remember {
            FeaturePageMode.entries.associateWith { Animatable(1f) }
        }
        val featureTransitionScope = rememberCoroutineScope()
        var featureLaunchSession by remember { mutableStateOf<FeatureLaunchSession?>(null) }
        var parkedFeatureLaunchSession by remember { mutableStateOf<FeatureLaunchSession?>(null) }
        var featureLaunchAnimation by remember { mutableStateOf<FeatureLaunchAnimation?>(null) }
        var featurePredictiveBackMotion by remember {
            mutableStateOf<FeaturePredictiveBackMotion?>(null)
        }
        val outgoingFeatureAnimations = remember { mutableStateListOf<FeatureLaunchAnimation>() }
        val featureQueuePressTokens = remember { mutableStateMapOf<FeaturePageMode, Long>() }
        val featureQueueHeldTokens = remember { mutableStateMapOf<FeaturePageMode, Long>() }
        val featureExternalIconScaleProviders = remember {
            FeaturePageMode.entries.associateWith { mode ->
                {
                    if (mode in featureQueuePressTokens) {
                        featureQueuePressScales.getValue(mode).value
                    } else {
                        1f
                    }
                }
            }
        }
        var nextFeatureQueuePressToken by remember { mutableStateOf(0L) }
        var featureRouteReadySession by remember { mutableStateOf<FeatureLaunchSession?>(null) }
        val featureLauncherOrigins = remember { mutableStateMapOf<FeaturePageMode, FeatureLaunchOrigin>() }
        var featureLauncherGridPosition by remember { mutableStateOf<Offset?>(null) }
        // Main-page content and title offsets outlive both pager items and detail navigation.
        val homePageScroll = rememberMainPageScrollState()
        val featurePageScroll = rememberMainPageScrollState()
        val aboutPageScroll = rememberMainPageScrollState()
        val featureLauncherScrollState = featurePageScroll.content
        ScrollResetEffect(mainPagerState.scrollResetGeneration) {
            homePageScroll.reset()
            featurePageScroll.reset()
            aboutPageScroll.reset()
        }
        var suppressRootTransition by remember { mutableStateOf(false) }
        val movableFeatureEntries = remember {
            FeaturePageMode.entries.associateWith { mode ->
                movableContentOf {
                    val transitionScrollState = rememberScrollState()
                    RootFeatureEntry(mode, transitionScrollState)
                }
            }
        }
        var rootViewportBounds by remember { mutableStateOf(Rect.Zero) }
        val bottomChromeBounds = remember { mutableStateMapOf<Boolean, Rect>() }
        val subPageActive = rootBackStack.size > 1
        val softwareUpdateState = rememberSoftwareUpdateUiState(aboutAutoCheckUpdateRequest)
        val currentRootRoute = navigator.current() as? RootRoute ?: RootRoute.Main
        val featurePagerIndex = visibleTabs.indexOfFirst { it.screenIndex == 1 }
        val featurePageDynamicBackgroundActive by remember(pagerState, featurePagerIndex) {
            derivedStateOf {
                featurePagerIndex >= 0 && abs(
                    featurePagerIndex - pagerState.currentPage - pagerState.currentPageOffsetFraction,
                ) < 1f
            }
        }
        val pagerLayoutDirection = LocalLayoutDirection.current
        val featurePageIsDark = colors.surface.luminance() < .5f
        val featurePageDynamicBackgroundVisible = backgroundStyle != 0 && featurePageDynamicBackgroundActive
        var bottomNavigationHeightPx by remember { mutableIntStateOf(0) }
        val density = LocalDensity.current
        val bottomNavigationHeight = with(density) {
            if (bottomNavigationHeightPx > 0) {
                bottomNavigationHeightPx.toDp()
            } else if (liquidGlassBottomBarEnabled && liquidBackdrop != null) {
                80.dp
            } else {
                88.dp
            }
        }

        LaunchedEffect(currentRootRoute) {
            if (
                currentRootRoute == RootRoute.SoftwareUpdate
            ) {
                softwareUpdateState.onCheckUpdates()
            }
        }

        LaunchedEffect(currentRootRoute, featureLaunchAnimation, featureLaunchSession) {
            val session = featureLaunchSession
            val route = session?.mode?.toRootRoute()
            if (
                suppressRootTransition &&
                featureLaunchAnimation == null &&
                route != null &&
                currentRootRoute == route
            ) {
                // NavDisplay must observe the instant spec for the ownership
                // handoff frame. Release it on the next vsync without keeping
                // feature input blocked or rebuilding the destination page.
                withFrameNanos { }
                if (
                    featureLaunchAnimation == null &&
                    featureLaunchSession === session &&
                    navigator.current() == route
                ) {
                    suppressRootTransition = false
                }
            }
        }

        fun resetFeatureIconFeedback() {
            featureQueuePressTokens.clear()
            featureQueueHeldTokens.clear()
            featureTransitionScope.launch {
                coroutineScope {
                    featureQueuePressScales.values.forEach { scale ->
                        launch { scale.snapTo(1f) }
                    }
                }
            }
        }

        fun releaseIconPress(mode: FeaturePageMode, pressToken: Long) {
            if (
                featureQueuePressTokens[mode] != pressToken ||
                featureQueueHeldTokens[mode] == pressToken
            ) {
                return
            }
            featureTransitionScope.launch {
                // Match IconPressAnimManager: ACTION_UP immediately restores
                // the real source view. The floating leash keeps its own frozen
                // pressed geometry, while the hidden source is already back at
                // 1x before it is ever handed back.
                if (
                    featureQueuePressTokens[mode] != pressToken ||
                    featureQueueHeldTokens[mode] == pressToken
                ) {
                    return@launch
                }
                val pressScale = featureQueuePressScales.getValue(mode)
                val remainingDuration = (
                    200f * (1f - pressScale.value).coerceIn(0f, 0.15f) / 0.15f
                ).roundToInt()
                pressScale.animateTo(
                    targetValue = 1f,
                    animationSpec = tween(
                        durationMillis = remainingDuration,
                        easing = FastOutSlowInEasing,
                    ),
                )
                if (
                    featureQueuePressTokens[mode] == pressToken &&
                    featureQueueHeldTokens[mode] != pressToken
                ) {
                    featureQueuePressTokens.remove(mode)
                }
            }
        }

        suspend fun prepareFeatureIconHandoff(session: FeatureLaunchSession) {
            val pressToken = session.pressToken ?: return
            if (
                featureQueuePressTokens[session.mode] != pressToken ||
                featureQueueHeldTokens[session.mode] == pressToken
            ) {
                return
            }
            featureQueuePressScales.getValue(session.mode).snapTo(1f)
            if (
                featureQueuePressTokens[session.mode] == pressToken &&
                featureQueueHeldTokens[session.mode] != pressToken
            ) {
                featureQueuePressTokens.remove(session.mode)
            }
        }

        suspend fun finishOutgoingFeatureAnimation(finished: FeatureLaunchAnimation) {
            if (outgoingFeatureAnimations.none { it === finished }) return
            prepareFeatureIconHandoff(finished.session)
            finished.predictiveBackMotion?.progressJob?.cancel()
            outgoingFeatureAnimations.remove(finished)
        }

        fun releaseCompletedIconPress(session: FeatureLaunchSession) {
            val pressToken = session.pressToken ?: return
            releaseIconPress(session.mode, pressToken)
        }

        fun currentFeatureWorkspaceVelocity() = FeatureWorkspaceVelocity(
            scale = featureWorkspaceScaleProgress.velocity,
            alpha = featureWorkspaceAlphaProgress.velocity,
            blur = featureWorkspaceBlurProgress.velocity,
        )

        fun beginFeatureClose(
            session: FeatureLaunchSession,
            interrupted: Boolean,
            predictiveBackMotion: FeaturePredictiveBackMotion? = null,
        ) {
            // First transfer the one movable detail tree to the floating leash.
            // The animation effect retires the Nav entry on a following frame,
            // after its old scene has replaced the content with a placeholder.
            suppressRootTransition = true
            val runningAnimation = featureLaunchAnimation
            val returnOrigin = featureLauncherOrigins[session.mode]
                ?.toReturnOrigin(
                    workspaceScale = 1f,
                    viewportBounds = rootViewportBounds,
                )
                ?: session.origin.toReturnOrigin(
                    workspaceScale = 1f,
                    viewportBounds = rootViewportBounds,
                )
            featureLaunchAnimation = if (runningAnimation?.session === session) {
                runningAnimation.copy(
                    direction = FeatureLaunchDirection.Closing,
                    returnOrigin = returnOrigin,
                    interrupted = true,
                    preserveWorkspace = runningAnimation.preserveWorkspace,
                    initialVelocity = runningAnimation.motion.velocitySnapshot(),
                    initialWorkspaceVelocity = currentFeatureWorkspaceVelocity(),
                    predictiveBackMotion = predictiveBackMotion
                        ?: runningAnimation.predictiveBackMotion,
                )
            } else {
                FeatureLaunchAnimation(
                    session = session,
                    direction = FeatureLaunchDirection.Closing,
                    motion = FeatureLaunchMotion(
                        initialGeometry = 1f,
                        alphaDirection = FeatureLaunchDirection.Closing,
                        useReturnOrigin = true,
                    ),
                    returnOrigin = returnOrigin,
                    interrupted = interrupted,
                    predictiveBackMotion = predictiveBackMotion,
                )
            }
        }

        fun startFeaturePredictiveBack(): FeaturePredictiveBackMotion? {
            val session = featureLaunchSession ?: parkedFeatureLaunchSession ?: return null
            val route = session.mode.toRootRoute() ?: return null
            if (
                !featurePageNewStyleEnabled ||
                featureLaunchAnimation != null ||
                navigator.current() != route
            ) {
                return null
            }
            if (featureLaunchSession == null) {
                featureLaunchSession = session
                parkedFeatureLaunchSession = null
            }
            featurePredictiveBackMotion?.progressJob?.cancel()
            val motion = FeaturePredictiveBackMotion()
            // Keep the real detail tree on the floating leash and expose Main
            // beneath it before the first non-zero progress frame. This is the
            // single-activity equivalent of C17 receiving the closing app leash
            // while Launcher is already prepared behind it.
            suppressRootTransition = true
            featurePredictiveBackMotion = motion
            navigator.pop()
            return motion
        }

        suspend fun updateFeaturePredictiveBack(
            motion: FeaturePredictiveBackMotion,
            event: BackEventCompat,
        ) {
            if (featurePredictiveBackMotion !== motion) return
            motion.updatePointer(event)
            motion.progressJob?.cancel()
            // BackEvent is already frame-paced by the system compositor. C17's
            // native DynamicAnimation can retarget a SurfaceControl in-place;
            // restarting Compose coroutines for every sample adds a full-frame
            // queue and feels detached from the finger. Drive the sample
            // directly here and reserve springs for cancel/commit only.
            motion.progress.snapTo(event.progress.coerceIn(0f, 1f))
        }

        fun cancelFeaturePredictiveBack(motion: FeaturePredictiveBackMotion) {
            motion.progressJob?.cancel()
            motion.progressJob = featureTransitionScope.launch {
                val initialVelocity = motion.progress.velocity
                motion.progress.stop()
                motion.progress.animateTo(
                    targetValue = 0f,
                    initialVelocity = initialVelocity,
                    animationSpec = spring(
                        dampingRatio = C17_PREDICTIVE_RESET_DAMPING,
                        stiffness = C17_PREDICTIVE_RESET_STIFFNESS,
                        visibilityThreshold = 0.0005f,
                    ),
                )
                if (
                    featurePredictiveBackMotion === motion &&
                    featureLaunchAnimation == null
                ) {
                    val session = featureLaunchSession
                    val route = session?.mode?.toRootRoute()
                    if (route != null && navigator.current() != route) {
                        navigator.push(route)
                    }
                    featurePredictiveBackMotion = null
                }
            }
        }

        suspend fun commitFeaturePredictiveBack(motion: FeaturePredictiveBackMotion) {
            if (featurePredictiveBackMotion !== motion) return
            motion.progressJob?.cancel()
            val initialVelocity = motion.progress.velocity
            motion.progress.stop()
            val session = featureLaunchSession ?: return
            // C17's Launcher content begins the continuation from the exact
            // amount already revealed by the hand-follow window.
            val workspaceStart = motion.c17WindowScale()
            coroutineScope {
                launch { featureWorkspaceScaleProgress.snapTo(workspaceStart) }
                launch { featureWorkspaceAlphaProgress.snapTo(workspaceStart) }
                launch { featureWorkspaceBlurProgress.snapTo(workspaceStart) }
            }
            beginFeatureClose(
                session = session,
                interrupted = true,
                predictiveBackMotion = motion,
            )
            featurePredictiveBackMotion = null
            // The inner close leash now travels to the source icon. Remove the
            // hand-follow coordinate space in parallel, preserving its current
            // value and velocity so the ownership handoff has no reset frame.
            motion.progressJob = featureTransitionScope.launch {
                motion.progress.animateTo(
                    targetValue = 0f,
                    initialVelocity = initialVelocity,
                    animationSpec = spring(
                        dampingRatio = C17_PREDICTIVE_RESET_DAMPING,
                        stiffness = C17_PREDICTIVE_RESET_STIFFNESS,
                        visibilityThreshold = 0.0005f,
                    ),
                )
            }
        }

        fun popRootRoute() {
            when (featureLaunchAnimation?.direction) {
                FeatureLaunchDirection.Opening -> {
                    val animation = featureLaunchAnimation ?: return
                    beginFeatureClose(animation.session, interrupted = true)
                    return
                }
                FeatureLaunchDirection.Closing -> return
                null -> Unit
            }
            val session = featureLaunchSession ?: parkedFeatureLaunchSession
            val sessionRoute = session?.mode?.toRootRoute()
            if (
                featurePageNewStyleEnabled &&
                featureLaunchAnimation == null &&
                session != null &&
                sessionRoute != null &&
                navigator.current() == sessionRoute
            ) {
                if (featureLaunchSession == null) {
                    featureLaunchSession = session
                    parkedFeatureLaunchSession = null
                }
                beginFeatureClose(session, interrupted = false)
                return
            }
            navigator.pop()
        }

        fun popToMainRoute() {
            featurePredictiveBackMotion?.progressJob?.cancel()
            featurePredictiveBackMotion = null
            featureLaunchAnimation = null
            featureLaunchSession = null
            parkedFeatureLaunchSession = null
            outgoingFeatureAnimations.forEach {
                it.predictiveBackMotion?.progressJob?.cancel()
            }
            outgoingFeatureAnimations.clear()
            featureRouteReadySession = null
            suppressRootTransition = false
            resetFeatureIconFeedback()
            navigator.popUntil { it is RootRoute.Main }
        }

        fun openFeatureSubPage(mode: FeaturePageMode) {
            val route = mode.toRootRoute() ?: return
            if (featureLaunchAnimation != null) return
            if (navigator.current() == route) return
            if (mode.isNestedPage || featureLaunchSession != null) {
                // Feature-to-feature navigation must use NavDisplay for both directions.
                // Park the launcher-style leash until the parent itself goes back to
                // the feature grid; otherwise it covers the nested transition.
                parkedFeatureLaunchSession = featureLaunchSession ?: parkedFeatureLaunchSession
                featureLaunchSession = null
                featureRouteReadySession = null
                suppressRootTransition = false
            }
            if (route in rootBackStack) {
                navigator.popUntil { it == route }
            } else {
                navigator.push(route)
            }
        }

        fun openAppErrorDetail(id: Long) {
            if (id <= 0 || featureLaunchAnimation != null || navigator.current() != RootRoute.FeatureAppErrors) return
            parkedFeatureLaunchSession = featureLaunchSession ?: parkedFeatureLaunchSession
            featureLaunchSession = null
            featureRouteReadySession = null
            suppressRootTransition = false
            navigator.push(RootRoute.AppErrorDetail(id))
        }

        fun openFeatureSubPageFromMain(
            mode: FeaturePageMode,
            origin: FeatureLaunchOrigin?,
            pressToken: Long?,
        ) {
            val route = mode.toRootRoute() ?: return
            // The real launcher item owns its own ACTION_UP feedback. Only the
            // transparent rapid-tap layer needs an external press token.
            val launchPressToken = pressToken
            val runningAnimation = featureLaunchAnimation
            if (runningAnimation?.direction == FeatureLaunchDirection.Opening) {
                // C17's OplusDragLayer intercepts launcher input while an app
                // opening record owns the transition. Do not let either the
                // real source grid or a stale queued gesture launch through
                // the foreground task surface.
                return
            }
            if (
                launchPressToken != null &&
                runningAnimation?.direction != FeatureLaunchDirection.Closing
            ) {
                // Queue tokens belong only to the launcher-visible close /
                // reverse phase. A token completing after that ownership has
                // changed is stale and must only run its press cleanup.
                return
            }
            val stableSession = featureLaunchSession?.takeIf { session ->
                runningAnimation == null && navigator.current() == session.mode.toRootRoute()
            }
            val activeAnimation = runningAnimation ?: stableSession?.let { session ->
                FeatureLaunchAnimation(
                    session = session,
                    direction = FeatureLaunchDirection.Opening,
                    motion = FeatureLaunchMotion(
                        initialGeometry = 1f,
                        alphaDirection = FeatureLaunchDirection.Closing,
                        useReturnOrigin = true,
                    ),
                    interrupted = true,
                    preserveWorkspace = true,
                )
            }

            if (activeAnimation != null && featurePageNewStyleEnabled && origin != null) {
                if (mode == activeAnimation.session.mode) {
                    // C17 reverses the same running leash in place. Reusing the
                    // motion object preserves its exact current frame; there is
                    // no close-end queue or restart from either endpoint.
                    if (runningAnimation?.direction == FeatureLaunchDirection.Closing) {
                        val resumedSession = runningAnimation.session.copy(
                            pressToken = launchPressToken,
                        )
                        featureLaunchSession = resumedSession
                        featureLaunchAnimation = runningAnimation.copy(
                            session = resumedSession,
                            direction = FeatureLaunchDirection.Opening,
                            interrupted = true,
                            preserveWorkspace = true,
                            initialVelocity = runningAnimation.motion.velocitySnapshot(),
                            initialWorkspaceVelocity = currentFeatureWorkspaceVelocity(),
                        )
                    }
                    return
                }

                // AnimationRegistry in C17 keeps every running close record.
                // Transfer the foreground leash to that registry immediately;
                // a newer tap never waits for an older close to finish.
                val oldRoute = activeAnimation.session.mode.toRootRoute()
                if (oldRoute != null && navigator.current() == oldRoute) {
                    suppressRootTransition = true
                    navigator.pop()
                }
                val replacedOutgoingAnimations = outgoingFeatureAnimations.filter {
                    it.session.mode == activeAnimation.session.mode
                }
                outgoingFeatureAnimations.removeAll(replacedOutgoingAnimations)
                replacedOutgoingAnimations.forEach { replaced ->
                    releaseCompletedIconPress(replaced.session)
                }
                val outgoingReturnOrigin = activeAnimation.returnOrigin
                    ?: featureLauncherOrigins[activeAnimation.session.mode]
                        ?.toReturnOrigin(
                            workspaceScale = 1f,
                            viewportBounds = rootViewportBounds,
                        )
                    ?: activeAnimation.session.origin.toReturnOrigin(
                        workspaceScale = 1f,
                        viewportBounds = rootViewportBounds,
                    )
                outgoingFeatureAnimations += activeAnimation.copy(
                    direction = FeatureLaunchDirection.Closing,
                    returnOrigin = outgoingReturnOrigin,
                    interrupted = true,
                    preserveWorkspace = true,
                    initialVelocity = activeAnimation.motion.velocitySnapshot(),
                )

                // If this icon already owns an outgoing close, promote that
                // exact leash back to foreground and reverse it. This also keeps
                // one movable content tree per mode, avoiding duplicate/ghost
                // icons during A -> B -> A and longer rapid sequences.
                val resumedAnimation = outgoingFeatureAnimations
                    .lastOrNull { it.session.mode == mode }
                    ?.also(outgoingFeatureAnimations::remove)
                val nextSession = resumedAnimation?.session?.copy(
                    // A running leash owns an immutable geometric target. A
                    // later A -> B -> A tap may replace only gesture ownership;
                    // retargeting its origin makes the same scalar jump.
                    pressToken = launchPressToken,
                ) ?: FeatureLaunchSession(
                    mode = mode,
                    origin = origin,
                    pressToken = launchPressToken,
                )
                featureLaunchSession = nextSession
                featureRouteReadySession = null
                featureLaunchAnimation = FeatureLaunchAnimation(
                    session = nextSession,
                    direction = FeatureLaunchDirection.Opening,
                    motion = resumedAnimation?.motion ?: FeatureLaunchMotion(
                        initialGeometry = 0f,
                        alphaDirection = FeatureLaunchDirection.Opening,
                        useReturnOrigin = false,
                    ),
                    returnOrigin = resumedAnimation?.returnOrigin,
                    interrupted = resumedAnimation != null,
                    preserveWorkspace = true,
                    initialVelocity = resumedAnimation?.motion?.velocitySnapshot(),
                    initialWorkspaceVelocity = currentFeatureWorkspaceVelocity(),
                )
                return
            }

            if (featurePageNewStyleEnabled && origin != null) {
                // The foreground close can finish before an older parallel
                // leash. A tap on that older icon must still promote and
                // reverse its existing leash; creating a second owner for the
                // same movableContent produces the intermittent missing/wrong
                // icon seen in A -> B -> C -> A stress taps.
                val resumedAnimation = outgoingFeatureAnimations
                    .lastOrNull { it.session.mode == mode }
                if (resumedAnimation != null) {
                    outgoingFeatureAnimations.remove(resumedAnimation)
                    val resumedSession = resumedAnimation.session.copy(
                        pressToken = launchPressToken,
                    )
                    featureLaunchSession = resumedSession
                    featureRouteReadySession = null
                    featureLaunchAnimation = resumedAnimation.copy(
                        session = resumedSession,
                        direction = FeatureLaunchDirection.Opening,
                        interrupted = true,
                        preserveWorkspace = true,
                        initialVelocity = resumedAnimation.motion.velocitySnapshot(),
                        initialWorkspaceVelocity = currentFeatureWorkspaceVelocity(),
                    )
                    return
                }
            }

            if (runningAnimation != null) return
            if (navigator.current() == route) return
            if (
                featurePageNewStyleEnabled &&
                origin != null &&
                rootViewportBounds.width > 0f &&
                rootViewportBounds.height > 0f
            ) {
                val session = FeatureLaunchSession(
                    mode = mode,
                    origin = origin,
                    pressToken = launchPressToken,
                )
                featureLaunchSession = session
                featureLaunchAnimation = FeatureLaunchAnimation(
                    session = session,
                    direction = FeatureLaunchDirection.Opening,
                    motion = FeatureLaunchMotion(
                        initialGeometry = 0f,
                        alphaDirection = FeatureLaunchDirection.Opening,
                        useReturnOrigin = false,
                    ),
                )
            } else {
                featureLaunchSession = null
                navigator.push(route)
            }
        }

        fun openAboutSubPage(mode: AboutPageMode) {
            val route = mode.toRootRoute() ?: return
            if (navigator.current() == route) return
            featurePredictiveBackMotion?.progressJob?.cancel()
            featurePredictiveBackMotion = null
            featureLaunchAnimation = null
            featureLaunchSession = null
            parkedFeatureLaunchSession = null
            outgoingFeatureAnimations.forEach {
                it.predictiveBackMotion?.progressJob?.cancel()
            }
            outgoingFeatureAnimations.clear()
            featureRouteReadySession = null
            suppressRootTransition = false
            resetFeatureIconFeedback()
            navigator.push(route)
        }

        LaunchedEffect(featureLaunchAnimation) {
            val animation = featureLaunchAnimation ?: return@LaunchedEffect
            val initialValue = when (animation.direction) {
                FeatureLaunchDirection.Opening -> 0f
                FeatureLaunchDirection.Closing -> 1f
            }
            val targetValue = when (animation.direction) {
                FeatureLaunchDirection.Opening -> 1f
                FeatureLaunchDirection.Closing -> 0f
            }
            if (!animation.interrupted) {
                if (!animation.preserveWorkspace) {
                    featureWorkspaceScaleProgress.snapTo(initialValue)
                    featureWorkspaceAlphaProgress.snapTo(initialValue)
                    featureWorkspaceBlurProgress.snapTo(initialValue)
                }
            }
            if (animation.direction == FeatureLaunchDirection.Closing) {
                val sessionRoute = animation.session.mode.toRootRoute()
                if (sessionRoute != null && navigator.current() == sessionRoute) {
                    navigator.pop()
                }
                // The task stays fully opaque through the first part of the
                // close, so NavDisplay can prepare Main underneath in parallel.
                // C17 starts its rect spring immediately instead of inserting a
                // fixed two-frame hold here.
            }
            val opening = animation.direction == FeatureLaunchDirection.Opening
            val geometryStiffness = if (opening) {
                C17_OPEN_GEOMETRY_STIFFNESS
            } else {
                C17_CLOSE_GEOMETRY_STIFFNESS
            }
            val geometryDamping = if (opening) {
                C17_OPEN_GEOMETRY_DAMPING
            } else {
                C17_CLOSE_GEOMETRY_DAMPING
            }
            val radiusStiffness = if (opening) {
                C17_OPEN_RADIUS_STIFFNESS
            } else {
                C17_CLOSE_RADIUS_STIFFNESS
            }
            val radiusDamping = if (opening) {
                C17_OPEN_RADIUS_DAMPING
            } else {
                C17_CLOSE_RADIUS_DAMPING
            }
            val workspaceStiffness = if (opening) {
                C17_OPEN_WORKSPACE_STIFFNESS
            } else {
                C17_CLOSE_WORKSPACE_STIFFNESS
            }
            val workspaceDamping = if (opening) {
                C17_OPEN_WORKSPACE_DAMPING
            } else {
                C17_CLOSE_WORKSPACE_DAMPING
            }
            val blurStiffness = if (opening) {
                C17_OPEN_BLUR_STIFFNESS
            } else {
                C17_CLOSE_BLUR_STIFFNESS
            }
            val blurDamping = if (opening) {
                C17_OPEN_BLUR_DAMPING
            } else {
                C17_CLOSE_BLUR_DAMPING
            }
            // Geometry is the authoritative lifecycle channel. Workspace
            // effects follow in parallel but never keep an already-finished
            // window registered and its source icon hidden.
            coroutineScope {
                val workspaceScaleJob = launch {
                    featureWorkspaceScaleProgress.animateTo(
                        targetValue = targetValue,
                        initialVelocity = animation.initialWorkspaceVelocity?.scale
                            ?: featureWorkspaceScaleProgress.velocity,
                        animationSpec = spring(
                            dampingRatio = workspaceDamping,
                            stiffness = workspaceStiffness,
                            visibilityThreshold = 0.001f,
                        ),
                    )
                }
                val workspaceAlphaJob = launch {
                    featureWorkspaceAlphaProgress.animateTo(
                        targetValue = targetValue,
                        initialVelocity = animation.initialWorkspaceVelocity?.alpha
                            ?: featureWorkspaceAlphaProgress.velocity,
                        animationSpec = spring(
                            dampingRatio = workspaceDamping,
                            stiffness = workspaceStiffness,
                            visibilityThreshold = 0.001f,
                        ),
                    )
                }
                val workspaceBlurJob = launch {
                    featureWorkspaceBlurProgress.animateTo(
                        targetValue = targetValue,
                        initialVelocity = animation.initialWorkspaceVelocity?.blur
                            ?: featureWorkspaceBlurProgress.velocity,
                        animationSpec = spring(
                            dampingRatio = blurDamping,
                            stiffness = blurStiffness,
                            visibilityThreshold = 0.001f,
                        ),
                    )
                }
                try {
                    animateFeatureLaunchMotion(
                        motion = animation.motion,
                        targetValue = targetValue,
                        initialVelocity = animation.initialVelocity,
                        geometryStiffness = geometryStiffness,
                        geometryDamping = geometryDamping,
                        radiusStiffness = radiusStiffness,
                        radiusDamping = radiusDamping,
                    )
                } finally {
                    workspaceScaleJob.cancel()
                    workspaceAlphaJob.cancel()
                    workspaceBlurJob.cancel()
                }
            }

            if (featureLaunchAnimation !== animation) return@LaunchedEffect
            val route = animation.session.mode.toRootRoute()
            when (animation.direction) {
                FeatureLaunchDirection.Opening -> {
                    suppressRootTransition = true
                    featureRouteReadySession = null
                    if (route != null && navigator.current() != route) {
                        navigator.push(route)
                    }
                    if (route != null) {
                        // NavDisplay switches targets asynchronously. Keep the
                        // opaque leash until the destination placeholder has
                        // actually been placed, then move the same content tree
                        // into it in one composition with no Main/blank flash.
                        withTimeoutOrNull(750L) {
                            snapshotFlow { featureRouteReadySession }
                                .first { it === animation.session }
                        }
                    }
                    if (featureLaunchAnimation !== animation) return@LaunchedEffect
                    animation.predictiveBackMotion?.progressJob?.cancel()
                    featureLaunchAnimation = null
                }
                FeatureLaunchDirection.Closing -> {
                    // Reset the hidden source before dropping the leash owner;
                    // otherwise Compose exposes a stale 0.85x icon for a frame
                    // and then visibly grows it back to 1x.
                    prepareFeatureIconHandoff(animation.session)
                    // Once the foreground (last-clicked) app has completed its
                    // full C17 close and Main is being handed back, no older
                    // parallel leash may remain above the now-visible launcher.
                    // C17 suppresses those stale icon surfaces and restores each
                    // original icon view; letting their springs settle offscreen
                    // here caused the grid to stay at mixed sizes for ~1 second.
                    outgoingFeatureAnimations.toList().forEach { outgoing ->
                        prepareFeatureIconHandoff(outgoing.session)
                        outgoing.predictiveBackMotion?.progressJob?.cancel()
                    }
                    outgoingFeatureAnimations.clear()
                    featureRouteReadySession = null
                    animation.predictiveBackMotion?.progressJob?.cancel()
                    featureLaunchAnimation = null
                    featureLaunchSession = null
                    suppressRootTransition = false
                }
            }
        }

        LaunchedEffect(openSoftwareUpdateRequest) {
            if (openSoftwareUpdateRequest > 0) {
                featurePredictiveBackMotion?.progressJob?.cancel()
                featurePredictiveBackMotion = null
                featureLaunchAnimation = null
                featureLaunchSession = null
                outgoingFeatureAnimations.forEach {
                    it.predictiveBackMotion?.progressJob?.cancel()
                }
                outgoingFeatureAnimations.clear()
                featureRouteReadySession = null
                suppressRootTransition = false
                resetFeatureIconFeedback()
                navigator.popUntil { it is RootRoute.Main }
                navigator.push(RootRoute.SoftwareUpdate)
            }
        }

        val rootUiState = RootUiState(
            currentTab = currentTab,
            rootGranted = rootGranted,
            blurEffectEnabled = blurEffectEnabled,
            featurePageNewStyleEnabled = featurePageNewStyleEnabled,
            featurePageDynamicBackgroundActive = featurePageDynamicBackgroundVisible,
            bottomBarStartupProgress = bottomBarStartupProgress,
            hiddenFeatureSourceModes = buildSet {
                featureLaunchSession?.mode?.let(::add)
                outgoingFeatureAnimations.forEach { add(it.session.mode) }
            },
            featureExternalIconScales = featureExternalIconScaleProviders,
            popDirectionFollowsSwipeEdge = popDirectionFollowsSwipeEdge,
            showFpsMonitor = showFpsMonitor,
            liquidGlassBottomBarEnabled = liquidGlassBottomBarEnabled && liquidBackdrop != null,
            bottomBarHideLabels = bottomBarHideLabels,
            mainPageSwipeEnabled = mainPageSwipeEnabled,
            subPageSwipeEnabled = subPageSwipeEnabled,
            appLanguageTag = appLanguageTag,
            appThemeMode = appThemeMode,
            appUiStyle = appUiStyle,
            appThemeKeyColor = appThemeKeyColor,
            appThemePaletteStyle = appThemePaletteStyle,
            appThemeColorSpec = appThemeColorSpec,
            permissionMonitorVisible = permissionMonitorVisible,
            nativeNotifyIconEnabled = nativeNotifyIconEnabled,
            nativeNotificationBubblesEnabled = nativeNotificationBubblesEnabled,
            systemUiInternationalNetworkDisplayEnabled =
                systemUiInternationalNetworkDisplayEnabled,
            systemUiHideMobileRoamingIndicatorEnabled =
                systemUiHideMobileRoamingIndicatorEnabled,
            systemUiInternationalNotificationStyleEnabled =
                systemUiInternationalNotificationStyleEnabled,
            systemUiHideQsEditEnabled = systemUiHideQsEditEnabled,
            systemUiHideQsSettingsEnabled = systemUiHideQsSettingsEnabled,
            systemUiHideQsTopCarrierEnabled = systemUiHideQsTopCarrierEnabled,
            systemUiHideQsMoreEnabled = systemUiHideQsMoreEnabled,
            systemUiForceNativeClipboardOverlayEnabled = systemUiForceNativeClipboardOverlayEnabled,
            settingsForceGoogleEntryEnabled = settingsForceGoogleEntryEnabled,
            gmsRegionRestrictionBypassEnabled = gmsRegionRestrictionBypassEnabled,
            extremeRefresh165Enabled = extremeRefresh165Enabled,
            launcherLayoutUnlocked = launcherLayoutUnlocked,
            assistantScreenOption = assistantScreenOption,
            recentTaskRadiusEnabled = recentTaskRadiusEnabled,
            recentTaskRadiusDp = recentTaskRadiusDp,
            aodEnhanceEnabled = aodEnhanceEnabled,
            aodInitDarkBrightness = aodInitDarkBrightness,
            aodInitBrightBrightness = aodInitBrightBrightness,
            aodRunningBrightnessMultiplier = aodRunningBrightnessMultiplier,
            aodAllDayUnlockEnabled = aodAllDayUnlockEnabled,
            aodSingleClickBlockEnabled = aodSingleClickBlockEnabled,
            assistantPowerMode = assistantPowerMode,
            assistantGestureCircleEnabled = assistantGestureCircleEnabled,
            assistantGestureCircleC17Enabled = assistantGestureCircleC17Enabled,
            assistantNativePowerEnabled = assistantNativePowerEnabled,
            assistantNativeCircleEnabled = assistantNativeCircleEnabled,
            visibleTabs = visibleTabs,
            selectedIndex = selectedIndex,
            bottomNavigationHeight = bottomNavigationHeight,
            blurBackdrop = blurBackdrop,
            liquidBackdrop = liquidBackdrop,
            softwareUpdateState = softwareUpdateState,
        )
        val rootActions = RootActions(
            onTabChange = onTabChange,
            onBlurEffectEnabledChange = onBlurEffectEnabledChange,
            onFeaturePageNewStyleEnabledChange = onFeaturePageNewStyleEnabledChange,
            onPopDirectionFollowsSwipeEdgeChange = onPopDirectionFollowsSwipeEdgeChange,
            onShowFpsMonitorChange = onShowFpsMonitorChange,
            onLiquidGlassBottomBarEnabledChange = onLiquidGlassBottomBarEnabledChange,
            onBottomBarHideLabelsChange = onBottomBarHideLabelsChange,
            onMainPageSwipeEnabledChange = onMainPageSwipeEnabledChange,
            onSubPageSwipeEnabledChange = onSubPageSwipeEnabledChange,
            onAppLanguageChange = onAppLanguageChange,
            onAppThemeModeChange = onAppThemeModeChange,
            onAppUiStyleChange = onAppUiStyleChange,
            onAppThemeKeyColorChange = onAppThemeKeyColorChange,
            onAppThemePaletteStyleChange = onAppThemePaletteStyleChange,
            onAppThemeColorSpecChange = onAppThemeColorSpecChange,
            onPermissionMonitorVisibleChange = onPermissionMonitorVisibleChange,
            onNativeNotifyIconEnabledChange = onNativeNotifyIconEnabledChange,
            onNativeNotificationBubblesEnabledChange = onNativeNotificationBubblesEnabledChange,
            onSystemUiInternationalNetworkDisplayEnabledChange =
                onSystemUiInternationalNetworkDisplayEnabledChange,
            onSystemUiHideMobileRoamingIndicatorEnabledChange =
                onSystemUiHideMobileRoamingIndicatorEnabledChange,
            onSystemUiInternationalNotificationStyleEnabledChange =
                onSystemUiInternationalNotificationStyleEnabledChange,
            onSystemUiHideQsEditEnabledChange = onSystemUiHideQsEditEnabledChange,
            onSystemUiHideQsSettingsEnabledChange = onSystemUiHideQsSettingsEnabledChange,
            onSystemUiHideQsTopCarrierEnabledChange = onSystemUiHideQsTopCarrierEnabledChange,
            onSystemUiHideQsMoreEnabledChange = onSystemUiHideQsMoreEnabledChange,
            onSystemUiForceNativeClipboardOverlayEnabledChange = onSystemUiForceNativeClipboardOverlayEnabledChange,
            onSettingsForceGoogleEntryEnabledChange = onSettingsForceGoogleEntryEnabledChange,
            onGmsRegionRestrictionBypassEnabledChange = onGmsRegionRestrictionBypassEnabledChange,
            onExtremeRefresh165EnabledChange = onExtremeRefresh165EnabledChange,
            onLauncherLayoutUnlockedChange = onLauncherLayoutUnlockedChange,
            onAssistantScreenOptionChange = onAssistantScreenOptionChange,
            onRecentTaskRadiusEnabledChange = onRecentTaskRadiusEnabledChange,
            onRecentTaskRadiusDpChange = onRecentTaskRadiusDpChange,
            onAodEnhanceEnabledChange = onAodEnhanceEnabledChange,
            onAodInitDarkBrightnessChange = onAodInitDarkBrightnessChange,
            onAodInitBrightBrightnessChange = onAodInitBrightBrightnessChange,
            onAodRunningBrightnessMultiplierChange = onAodRunningBrightnessMultiplierChange,
            onAodAllDayUnlockEnabledChange = onAodAllDayUnlockEnabledChange,
            onAodSingleClickBlockEnabledChange = onAodSingleClickBlockEnabledChange,
            onAssistantPowerModeChange = onAssistantPowerModeChange,
            onAssistantGestureCircleEnabledChange = onAssistantGestureCircleEnabledChange,
            onAssistantGestureCircleC17EnabledChange =
                onAssistantGestureCircleC17EnabledChange,
            onAssistantNativePowerEnabledChange = onAssistantNativePowerEnabledChange,
            onAssistantNativeCircleEnabledChange = onAssistantNativeCircleEnabledChange,
            onBottomNavigationHeightChange = { bottomNavigationHeightPx = it },
            onBottomChromeBoundsChange = { liquid, bounds -> bottomChromeBounds[liquid] = bounds },
            onHapticClick = hapticClick,
            popRootRoute = { popRootRoute() },
            popToMainRoute = ::popToMainRoute,
            openFeatureSubPage = ::openFeatureSubPage,
            openAppErrorDetail = ::openAppErrorDetail,
            openFeatureSubPageFromMain = { mode, origin ->
                openFeatureSubPageFromMain(mode, origin, pressToken = null)
            },
            openAboutSubPage = ::openAboutSubPage,
            requestAboutAutoCheckUpdate = { aboutAutoCheckUpdateRequest += 1 },
        )

        val liquidBottomChrome = remember {
            movableContentOf<Boolean> { visible -> RootBottomChrome(visible, liquidOnly = true) }
        }
        val standardBottomChrome = remember {
            movableContentOf<Boolean> { visible -> RootBottomChrome(visible, liquidOnly = false) }
        }
        val bottomChrome: @Composable (Boolean, Boolean) -> Unit = { visible, liquidOnly ->
            if (liquidOnly) liquidBottomChrome(visible) else standardBottomChrome(visible)
        }
        val featureEntryContent: @Composable (FeaturePageMode) -> Unit = { mode ->
            val animation = featureLaunchAnimation
            val session = featureLaunchSession
            val ownedByFloatingLeash = session?.mode == mode ||
                outgoingFeatureAnimations.any { it.session.mode == mode }
            if (ownedByFloatingLeash) {
                // While the floating leash owns the real movable tree, the Nav
                // scene gets only a readiness marker. This prevents Compose from
                // invoking the same movable content at two positions and lets us
                // wait until NavDisplay has actually placed its async target.
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .onGloballyPositioned {
                            if (
                                session?.mode == mode &&
                                animation?.direction == FeatureLaunchDirection.Opening &&
                                navigator.current() == mode.toRootRoute()
                            ) {
                                featureRouteReadySession = session
                            }
                        },
                )
            } else {
                movableFeatureEntries.getValue(mode).invoke()
            }
        }
        val rootEntryProvider = remember(rootBackStack) {
            entryProvider<NavKey> {
            entry<RootRoute.Main> {
                        val ui = LocalRootUiState.current
                        val actions = LocalRootActions.current
                        val mainPagerState = LocalMainPagerState.current
                        val mainSceneContainerColor = if (
                            ui.featurePageDynamicBackgroundActive
                        ) {
                            Color.Transparent
                        } else run {
                            COUITheme.colorScheme.surface
                        }
                        Scaffold(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(mainSceneContainerColor),
                            containerColor = mainSceneContainerColor,
                            popupHost = {},
                            bottomBar = {
                                if (!ui.liquidGlassBottomBarEnabled || ui.liquidBackdrop == null) {
                                    Box(Modifier.fillMaxWidth().height(ui.bottomNavigationHeight))
                                }
                            },
                        ) {
                            Box(modifier = Modifier.fillMaxSize()) {
                                HorizontalPager(
                                    state = mainPagerState.pagerState,
                                    userScrollEnabled = ui.mainPageSwipeEnabled,
                                    verticalAlignment = Alignment.Top,
                                    modifier = Modifier.fillMaxSize(),
                                ) { pageIndex ->
                                    val targetTab = ui.visibleTabs.getOrNull(pageIndex)?.screenIndex ?: ui.currentTab
                                    when (targetTab) {
                                        1 -> FeatureMainRoute(
                                            modifier = Modifier.fillMaxSize(),
                                            subPageBottomExtension = ui.bottomNavigationHeight,
                                            blurBackdrop = ui.blurBackdrop,
                                            newStyleEnabled = ui.featurePageNewStyleEnabled,
                                            externalScrollState = featureLauncherScrollState,
                                            externalTopAppBarState = featurePageScroll.appBar,
                                            onGridPositionChanged = { position ->
                                                val transformActive = featureLaunchAnimation != null ||
                                                    featurePredictiveBackMotion != null
                                                val workspaceScale = if (transformActive) {
                                                    val progress = featurePredictiveBackMotion?.c17WindowScale()
                                                        ?: featureWorkspaceScaleProgress.value
                                                    lerpFloat(1f, C17_SOURCE_SCALE, progress.coerceIn(0f, 1f))
                                                } else {
                                                    1f
                                                }
                                                featureLauncherGridPosition = unscaledFeatureGridPosition(
                                                    position, rootViewportBounds, workspaceScale,
                                                )
                                            },
                                            hiddenSourceModes = ui.hiddenFeatureSourceModes,
                                            externalIconScales = ui.featureExternalIconScales,
                                            onLaunchOriginChanged = { mode, origin ->
                                                // Cache icon bounds without the workspace transform.
                                                if (
                                                    featureLaunchAnimation == null &&
                                                    outgoingFeatureAnimations.isEmpty() &&
                                                    rootViewportBounds.width > 0f
                                                ) {
                                                    val gridPosition = featureLauncherGridPosition ?: Offset.Zero
                                                    val measured = origin.copy(
                                                        gridLeft = gridPosition.x,
                                                        gridTop = gridPosition.y,
                                                    )
                                                    if (featureLauncherOrigins[mode] != measured) {
                                                        featureLauncherOrigins[mode] = measured
                                                    }
                                                }
                                            },
                                            onOpen = { mode, origin ->
                                                run {
                                                    val gridPosition = featureLauncherGridPosition ?: Offset.Zero
                                                    actions.openFeatureSubPageFromMain(
                                                        mode,
                                                        origin?.copy(
                                                            gridLeft = gridPosition.x,
                                                            gridTop = gridPosition.y,
                                                        ),
                                                    )
                                                }
                                            },
                                        )
                                        2 -> ToolsMainPage { mode -> actions.openFeatureSubPage(mode) }
                                        3 -> AboutMainRoute(
                                            modifier = Modifier.fillMaxSize(),
                                            blurBackdrop = ui.blurBackdrop,
                                            bottomContentPadding = ui.bottomNavigationHeight,
                                            externalScrollState = aboutPageScroll.content,
                                            externalTopAppBarState = aboutPageScroll.appBar,
                                            onOpenAppSettings = { actions.openAboutSubPage(AboutPageMode.AppSettings) },
                                            onOpenSoftwareUpdate = { actions.openAboutSubPage(AboutPageMode.Update) },
                                            onOpenLogs = { actions.openAboutSubPage(AboutPageMode.Logs) },
                                            onOpenContributors = { actions.openAboutSubPage(AboutPageMode.Contributors) },
                                            onOpenReferences = { actions.openAboutSubPage(AboutPageMode.References) },
                                        )
                                        else -> Page(
                                            modifier = Modifier.fillMaxSize(),
                                            currentTab = targetTab,
                                            rootGranted = ui.rootGranted,
                                            bottomChromePadding = ui.bottomNavigationHeight,
                                            onHomeHeroLongPress = {
                                                actions.onTabChange(3)
                                                mainPagerState.animateToPage(
                                                    ui.visibleTabs.indexOfFirst { it.screenIndex == 3 }.coerceAtLeast(0),
                                                )
                                                actions.openAboutSubPage(AboutPageMode.Update)
                                                actions.requestAboutAutoCheckUpdate()
                                            },
                                            onOpenDeviceDetails = { navigator.push(RootRoute.DeviceDetails) },
                                            blurBackdrop = ui.blurBackdrop,
                                            externalScrollState = homePageScroll.content,
                                            externalTopAppBarState = homePageScroll.appBar,
                                        )
                                    }
                                }
                            }
                            COUIPopupHost()
                        }
            }
            entry<RootRoute.FeatureDesktop> {
                featureEntryContent(FeaturePageMode.Desktop)
            }
            entry<RootRoute.FeatureEnabledFeatures> {
                featureEntryContent(FeaturePageMode.EnabledFeatures)
            }
            entry<RootRoute.FeatureUpdates> {
                featureEntryContent(FeaturePageMode.Updates)
            }
            entry<RootRoute.FeatureCoui> {
                featureEntryContent(FeaturePageMode.Coui)
            }
            entry<RootRoute.FeatureTools> {
                featureEntryContent(FeaturePageMode.Tools)
            }
            entry<RootRoute.FeatureMore> {
                featureEntryContent(FeaturePageMode.More)
            }
            entry<RootRoute.FeatureDesktopLayout> {
                featureEntryContent(FeaturePageMode.DesktopLayout)
            }
            entry<RootRoute.FeatureDesktopIcons> {
                featureEntryContent(FeaturePageMode.DesktopIcons)
            }
            entry<RootRoute.FeatureDesktopRecent> {
                featureEntryContent(FeaturePageMode.DesktopRecent)
            }
            entry<RootRoute.FeatureDesktopHiddenApps> {
                featureEntryContent(FeaturePageMode.DesktopHiddenApps)
            }
            entry<RootRoute.FeatureDesktopPages> {
                featureEntryContent(FeaturePageMode.DesktopPages)
            }
            entry<RootRoute.FeatureSystemUi> {
                featureEntryContent(FeaturePageMode.SystemUi)
            }
            entry<RootRoute.FeatureSystemUiNative> {
                featureEntryContent(FeaturePageMode.SystemUiNative)
            }
            entry<RootRoute.FeatureSystemUiBackGesture> {
                featureEntryContent(FeaturePageMode.SystemUiBackGesture)
            }
            entry<RootRoute.FeatureSystemUiBackGestureArea> {
                featureEntryContent(FeaturePageMode.SystemUiBackGestureArea)
            }
            entry<RootRoute.FeatureSystemUiVolume> {
                featureEntryContent(FeaturePageMode.SystemUiVolume)
            }
            entry<RootRoute.FeatureSystemUiDynamicColor> {
                featureEntryContent(FeaturePageMode.SystemUiDynamicColor)
            }
            entry<RootRoute.FeatureSystemUiClock> {
                featureEntryContent(FeaturePageMode.SystemUiClock)
            }
            entry<RootRoute.FeatureSystemUiStatusBarLayout> {
                featureEntryContent(FeaturePageMode.SystemUiStatusBarLayout)
            }
            entry<RootRoute.FeatureSystemUiStatusBarNetwork> {
                featureEntryContent(FeaturePageMode.SystemUiStatusBarNetwork)
            }
            entry<RootRoute.FeatureSystemUiStatusBarSpeed> {
                featureEntryContent(FeaturePageMode.SystemUiStatusBarSpeed)
            }
            entry<RootRoute.FeatureSystemUiStatusBarPower> {
                featureEntryContent(FeaturePageMode.SystemUiStatusBarPower)
            }
            entry<RootRoute.FeatureSystemUiStatusBarBattery> {
                featureEntryContent(FeaturePageMode.SystemUiStatusBarBattery)
            }
            entry<RootRoute.FeatureSystemUiStatusBarInteraction> {
                featureEntryContent(FeaturePageMode.SystemUiStatusBarInteraction)
            }
            entry<RootRoute.FeatureSystemUiStatusBar> {
                featureEntryContent(FeaturePageMode.SystemUiStatusBar)
            }
            entry<RootRoute.FeatureSystemUiIconOrder> {
                featureEntryContent(FeaturePageMode.SystemUiIconOrder)
            }
            entry<RootRoute.FeatureSystemUiFluidCloud> {
                featureEntryContent(FeaturePageMode.SystemUiFluidCloud)
            }
            entry<RootRoute.FeatureSystemUiFluidCloudMediaBlacklist> {
                featureEntryContent(FeaturePageMode.SystemUiFluidCloudMediaBlacklist)
            }
            entry<RootRoute.FeatureSystemUiNotificationCenter> {
                featureEntryContent(FeaturePageMode.SystemUiNotificationCenter)
            }
            entry<RootRoute.FeatureSystemUiControlCenter> {
                featureEntryContent(FeaturePageMode.SystemUiControlCenter)
            }
            entry<RootRoute.FeatureSystemUiCornerSettings> {
                featureEntryContent(FeaturePageMode.SystemUiCornerSettings)
            }
            entry<RootRoute.FeatureSystemUiPercentageSettings> {
                featureEntryContent(FeaturePageMode.SystemUiPercentageSettings)
            }
            entry<RootRoute.FeatureSystemUiSideVolumePercentageSettings> {
                featureEntryContent(FeaturePageMode.SystemUiSideVolumePercentageSettings)
            }
            entry<RootRoute.FeatureSystemUiSmallWindow> {
                featureEntryContent(FeaturePageMode.SystemUiSmallWindow)
            }
            entry<RootRoute.FeatureSystemUiLockScreen> {
                featureEntryContent(FeaturePageMode.SystemUiLockScreen)
            }
            entry<RootRoute.FeatureSystemUiNavigationBar> {
                featureEntryContent(FeaturePageMode.SystemUiNavigationBar)
            }
            entry<RootRoute.FeatureNotificationRemoval> {
                featureEntryContent(FeaturePageMode.NotificationRemoval)
            }
            entry<RootRoute.FeatureInstaller> {
                featureEntryContent(FeaturePageMode.Installer)
            }
            entry<RootRoute.FeatureMobileNetwork> {
                featureEntryContent(FeaturePageMode.MobileNetwork)
            }
            entry<RootRoute.FeatureAndroidSystem> {
                featureEntryContent(FeaturePageMode.AndroidSystem)
            }
            entry<RootRoute.FeatureCorePatch> {
                featureEntryContent(FeaturePageMode.CorePatch)
            }
            entry<RootRoute.FeatureSideKey> {
                featureEntryContent(FeaturePageMode.SideKey)
            }
            entry<RootRoute.FeatureEsim> {
                featureEntryContent(FeaturePageMode.Esim)
            }
            entry<RootRoute.FeatureEsimDiagnostics> {
                featureEntryContent(FeaturePageMode.EsimDiagnostics)
            }
            entry<RootRoute.FeatureAppMarket> {
                featureEntryContent(FeaturePageMode.AppMarket)
            }
            entry<RootRoute.FeatureBattery> {
                featureEntryContent(FeaturePageMode.Battery)
            }
            entry<RootRoute.FeatureTrafficManagement> {
                featureEntryContent(FeaturePageMode.TrafficManagement)
            }
            entry<RootRoute.FeaturePhoneManager> {
                featureEntryContent(FeaturePageMode.PhoneManager)
            }
            entry<RootRoute.FeatureThemeStore> {
                featureEntryContent(FeaturePageMode.ThemeStore)
            }
            entry<RootRoute.FeatureGallery> {
                featureEntryContent(FeaturePageMode.Gallery)
            }
            entry<RootRoute.FeatureSecurePay> {
                featureEntryContent(FeaturePageMode.SecurePay)
            }
            entry<RootRoute.FeatureGameAssistant> {
                featureEntryContent(FeaturePageMode.GameAssistant)
            }
            entry<RootRoute.FeatureOShare> {
                featureEntryContent(FeaturePageMode.OShare)
            }
            entry<RootRoute.FeatureSoftwareUpdate> {
                featureEntryContent(FeaturePageMode.SoftwareUpdate)
            }
            entry<RootRoute.FeatureBrowser> { featureEntryContent(FeaturePageMode.Browser) }
            entry<RootRoute.FeatureWeather> { featureEntryContent(FeaturePageMode.Weather) }
            entry<RootRoute.FeaturePhotoPicker> { featureEntryContent(FeaturePageMode.PhotoPicker) }
            entry<RootRoute.FeatureEngineerMode> { featureEntryContent(FeaturePageMode.EngineerMode) }
            entry<RootRoute.FeaturePictorial> { featureEntryContent(FeaturePageMode.Pictorial) }
            entry<RootRoute.FeatureKeyboard> {
                featureEntryContent(FeaturePageMode.Keyboard)
            }
            entry<RootRoute.FeatureQuickAppServices> {
                featureEntryContent(FeaturePageMode.QuickAppServices)
            }
            entry<RootRoute.FeatureFileManager> {
                featureEntryContent(FeaturePageMode.FileManager)
            }
            entry<RootRoute.FeatureGoogleMessages> {
                featureEntryContent(FeaturePageMode.GoogleMessages)
            }
            entry<RootRoute.FeatureSystemMessages> {
                featureEntryContent(FeaturePageMode.SystemMessages)
            }
            entry<RootRoute.FeatureAppErrors> {
                featureEntryContent(FeaturePageMode.AppErrors)
            }
            entry<RootRoute.FeatureNotificationBatch> {
                featureEntryContent(FeaturePageMode.NotificationBatch)
            }
            entry<RootRoute.AppErrorDetail> { route ->
                val ui = LocalRootUiState.current
                val actions = LocalRootActions.current
                com.mi.onextbox.ui.screens.AppErrorTrackingRoute(
                    modifier = Modifier.fillMaxSize(),
                    blurBackdrop = rememberChromeBlurBackdrop(ui.blurEffectEnabled),
                    onBack = actions.popRootRoute,
                    onOpenDetail = actions.openAppErrorDetail,
                    detailId = route.id,
                )
            }
            entry<RootRoute.FeatureAthena> {
                featureEntryContent(FeaturePageMode.Athena)
            }
            entry<RootRoute.FeatureSettings> {
                featureEntryContent(FeaturePageMode.Settings)
            }
            entry<RootRoute.FeatureSettingsRegion> {
                featureEntryContent(FeaturePageMode.SettingsRegion)
            }
            entry<RootRoute.FeatureSettingsAppearance> {
                featureEntryContent(FeaturePageMode.SettingsAppearance)
            }
            entry<RootRoute.FeatureSettingsApps> {
                featureEntryContent(FeaturePageMode.SettingsApps)
            }
            entry<RootRoute.FeatureSettingsPermissions> {
                featureEntryContent(FeaturePageMode.SettingsPermissions)
            }
            entry<RootRoute.FeatureSettingsAboutDevice> {
                featureEntryContent(FeaturePageMode.SettingsAboutDevice)
            }
            entry<RootRoute.FeatureSettingsRealme> {
                featureEntryContent(FeaturePageMode.SettingsRealme)
            }
            entry<RootRoute.FeatureSecurityPermission> {
                featureEntryContent(FeaturePageMode.SecurityPermission)
            }
            entry<RootRoute.FeatureTouchSampling> {
                featureEntryContent(FeaturePageMode.TouchSampling)
            }
            entry<RootRoute.FeatureWallpapers> {
                featureEntryContent(FeaturePageMode.Wallpapers)
            }
            entry<RootRoute.FeatureAod> {
                featureEntryContent(FeaturePageMode.Aod)
            }
            entry<RootRoute.FeatureScreenshot> {
                featureEntryContent(FeaturePageMode.Screenshot)
            }
            entry<RootRoute.FeatureScreenRecording> {
                featureEntryContent(FeaturePageMode.ScreenRecording)
            }
            entry<RootRoute.FeatureCamera> {
                featureEntryContent(FeaturePageMode.Camera)
            }
            entry<RootRoute.FeatureTranslation> {
                featureEntryContent(FeaturePageMode.Translation)
            }
            entry<RootRoute.FeatureSmartSidebar> {
                featureEntryContent(FeaturePageMode.SmartSidebar)
            }
            entry<RootRoute.FeatureAppInstaller> {
                featureEntryContent(FeaturePageMode.AppInstaller)
            }
            entry<RootRoute.FeaturePackageInstaller> {
                featureEntryContent(FeaturePageMode.PackageInstaller)
            }
            entry<RootRoute.FeatureAssistant> {
                featureEntryContent(FeaturePageMode.Assistant)
            }
            entry<RootRoute.AppSettings> { RootAboutEntry(AboutPageMode.AppSettings) }
            entry<RootRoute.Logs> { RootAboutEntry(AboutPageMode.Logs) }
            entry<RootRoute.DeveloperOptions> { RootAboutEntry(AboutPageMode.DeveloperOptions) }
            entry<RootRoute.DeviceDetails> {
                val ui = LocalRootUiState.current
                val actions = LocalRootActions.current
                com.mi.onextbox.ui.settings.SettingsPageSurface(
                    title = "设备详细信息", modifier = Modifier.fillMaxSize(),
                    showBack = true, onBack = actions.popRootRoute,
                    blurBackdrop = rememberChromeBlurBackdrop(ui.blurEffectEnabled),
                ) {
                    com.mi.onextbox.ui.home.HomeHardwareInfo(rootGranted = ui.rootGranted, refreshKey = 0)
                }
            }
            entry<RootRoute.SoftwareUpdate> { RootAboutEntry(AboutPageMode.Update) }
            entry<RootRoute.SoftwareUpdateSettings> { RootAboutEntry(AboutPageMode.UpdateSettings) }
            entry<RootRoute.SoftwareUpdateReleaseNotes> {
                RootAboutEntry(AboutPageMode.UpdateReleaseNotes)
            }
            entry<RootRoute.Contributors> { RootAboutEntry(AboutPageMode.Contributors) }
            entry<RootRoute.References> { RootAboutEntry(AboutPageMode.References) }
            }
        }

        val rootEntries = rememberDecoratedNavEntries(
            backStack = rootBackStack,
            entryDecorators = listOf(rememberSaveableStateHolderNavEntryDecorator()),
            entryProvider = rootEntryProvider,
        )

        val rootTransitionEffects = remember(popDirectionFollowsSwipeEdge, appUiStyle) {
            NavDisplayTransitionEffects(
                // COUI detail pages draw through the status bar. Clipping the
                // entire navigation scene rounds off and cuts that top strip
                // while a nested page slides in or out.
                enableCornerClip = false,
                dimAmount = 0.5f,
                // Block only outgoing scenes; the incoming page can interrupt navigation.
                blockInputDuringTransition = true,
                popDirectionFollowsSwipeEdge = false,
            )
        }
        MainScreenBackHandler(
            mainPagerState = mainPagerState,
            navigator = navigator,
            onTabChange = onTabChange,
        )

        CompositionLocalProvider(
            LocalRootNavigator provides navigator,
            LocalMainPagerState provides mainPagerState,
            LocalRootUiState provides rootUiState,
            LocalRootActions provides rootActions,
            LocalFeatureSpotlight provides featureSpotlight,
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .swipeBack(subPageSwipeEnabled && (navigator.current() != RootRoute.Main || featurePredictiveBackMotion != null) && featureLaunchAnimation == null)
                    .onGloballyPositioned { coordinates ->
                        rootViewportBounds = coordinates.boundsInWindow()
                    },
            ) {
                val activeAnimation = featureLaunchAnimation
                val activeSession = featureLaunchSession
                val handFollowMotion = featurePredictiveBackMotion
                val handFollowWorkspaceProgress = handFollowMotion?.c17WindowScale()
                val launchWorkspaceScaleProgress = handFollowWorkspaceProgress
                    ?: featureWorkspaceScaleProgress.value
                val launchWorkspaceAlphaProgress = handFollowWorkspaceProgress
                    ?: featureWorkspaceAlphaProgress.value
                val launchWorkspaceBlurProgress = handFollowWorkspaceProgress
                    ?: featureWorkspaceBlurProgress.value
                val workspaceVisualScale = lerpFloat(
                    1f,
                    C17_SOURCE_SCALE,
                    launchWorkspaceScaleProgress.coerceIn(0f, 1f),
                )
                val baseScene: @Composable () -> Unit = {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(colors.surface),
                    ) {
                        if (featurePageDynamicBackgroundVisible) {
                            Box(Modifier.matchParentSize().clipToBounds()) {
                                com.mi.onextbox.ui.screens.FeatureBackgroundEffect(
                                    style = backgroundStyle,
                                    dark = featurePageIsDark,
                                    surface = colors.surface,
                                    accent = colors.primary,
                                    modifier = Modifier.fillMaxSize().graphicsLayer {
                                        val pageExtent = pagerState.layoutInfo.let { it.pageSize + it.pageSpacing }
                                        val pageOffset = featurePagerIndex - pagerState.currentPage -
                                            pagerState.currentPageOffsetFraction
                                        translationX = pageOffset * pageExtent *
                                            if (pagerLayoutDirection == LayoutDirection.Rtl) -1f else 1f
                                        clip = true
                                    },
                                )
                            }
                        }
                        RootNavDisplay(
                            entries = rootEntries,
                            modifier = Modifier
                                .fillMaxSize()
                                .imePadding()
                                .then(
                                    if (
                                        rootUiState.liquidGlassBottomBarEnabled &&
                                        rootUiState.liquidBackdrop != null
                                    ) {
                                        Modifier.liquidLayerBackdrop(rootUiState.liquidBackdrop)
                                    } else {
                                        Modifier
                                    },
                                ),
                            onBack = { popRootRoute() },
                            animate = !suppressRootTransition,
                            handleBack = featureLaunchAnimation == null && featurePredictiveBackMotion == null &&
                                !(featurePageNewStyleEnabled &&
                                    (featureLaunchSession ?: parkedFeatureLaunchSession)?.mode?.toRootRoute()
                                        ?.let { it == navigator.current() } == true),
                            transitionEffects = rootTransitionEffects,
                        )
                    }
                }

                C17StableBaseSceneLayer(
                    transformActive = activeAnimation != null || handFollowMotion != null,
                    workspaceScaleProgress = launchWorkspaceScaleProgress,
                    workspaceAlphaProgress = launchWorkspaceAlphaProgress,
                    workspaceBlurProgress = launchWorkspaceBlurProgress,
                ) {
                    baseScene()
                }

                val closingWindows = outgoingFeatureAnimations.toList()
                val activeReturnOrigin = activeAnimation?.returnOrigin
                    ?.atGridPosition(featureLauncherGridPosition)
                    ?.toReturnOrigin(
                        workspaceScale = workspaceVisualScale,
                        viewportBounds = rootViewportBounds,
                    )
                closingWindows.forEach { outgoingAnimation ->
                    key("icon", outgoingAnimation) {
                        C17ClosingFeatureWindowLayer(
                            animation = outgoingAnimation,
                            viewportBounds = rootViewportBounds,
                            workspaceScale = workspaceVisualScale,
                            gridPosition = featureLauncherGridPosition,
                            onFinished = ::finishOutgoingFeatureAnimation,
                            surface = FeatureWindowSurface.Icon,
                        ) {}
                    }
                }
                if (activeSession != null) {
                    C17FeatureWindowLayer(
                        session = activeSession,
                        direction = activeAnimation?.direction ?: FeatureLaunchDirection.Opening,
                        motion = activeAnimation?.motion,
                        predictiveBackMotion = activeAnimation?.predictiveBackMotion ?: handFollowMotion,
                        returnOrigin = activeReturnOrigin,
                        viewportBounds = rootViewportBounds,
                        surface = FeatureWindowSurface.Icon,
                    ) {}
                }
                val retainFeatureChrome = activeSession != null ||
                    parkedFeatureLaunchSession != null || closingWindows.isNotEmpty() || handFollowMotion != null
                val chromeRouteVisibility by animateFloatAsState(
                    targetValue = if (currentRootRoute == RootRoute.Main || retainFeatureChrome) 1f else 0f,
                    animationSpec = tween(220),
                    label = "Bottom chrome route visibility",
                )
                val bottomChromeHideDistancePx = with(density) {
                    (rootUiState.bottomNavigationHeight + 48.dp).toPx()
                }
                C17StableChromeSceneLayer(
                    transformActive = activeAnimation != null || handFollowMotion != null,
                    workspaceScaleProgress = launchWorkspaceScaleProgress,
                    workspaceAlphaProgress = launchWorkspaceAlphaProgress,
                    hidden = currentRootRoute != RootRoute.Main &&
                        (retainFeatureChrome || chromeRouteVisibility == 0f),
                    routeVisibility = chromeRouteVisibility,
                ) {
                    Box(
                        modifier = Modifier.fillMaxSize().then(
                            if (rootUiState.liquidGlassBottomBarEnabled && rootUiState.liquidBackdrop != null) {
                                Modifier
                            } else Modifier.imePadding(),
                        ).graphicsLayer {
                            alpha = 1f
                            translationY = (1f - chromeRouteVisibility) * bottomChromeHideDistancePx
                            compositingStrategy = CompositingStrategy.ModulateAlpha
                        },
                        contentAlignment = Alignment.BottomCenter,
                    ) {
                        bottomChrome(
                            true,
                            rootUiState.liquidGlassBottomBarEnabled && rootUiState.liquidBackdrop != null,
                        )
                    }
                }
                closingWindows.forEach { outgoingAnimation ->
                    key("task", outgoingAnimation) {
                        C17ClosingFeatureWindowLayer(
                            animation = outgoingAnimation,
                            viewportBounds = rootViewportBounds,
                            workspaceScale = workspaceVisualScale,
                            gridPosition = featureLauncherGridPosition,
                            onFinished = ::finishOutgoingFeatureAnimation,
                            surface = FeatureWindowSurface.Task,
                        ) {
                            movableFeatureEntries.getValue(outgoingAnimation.session.mode).invoke()
                        }
                    }
                }
                if (activeSession != null) {
                    C17FeatureWindowLayer(
                        session = activeSession,
                        direction = activeAnimation?.direction ?: FeatureLaunchDirection.Opening,
                        motion = activeAnimation?.motion,
                        predictiveBackMotion = activeAnimation?.predictiveBackMotion ?: handFollowMotion,
                        returnOrigin = activeReturnOrigin,
                        viewportBounds = rootViewportBounds,
                        surface = FeatureWindowSurface.Task,
                    ) {
                        movableFeatureEntries.getValue(activeSession.mode).invoke()
                    }
                }

                val keepLauncherHitTargets =
                    activeAnimation?.direction == FeatureLaunchDirection.Closing ||
                        featureQueueHeldTokens.isNotEmpty()
                if (keepLauncherHitTargets) {
                    FeatureLaunchQueueHitLayer(
                        origins = featureLauncherOrigins,
                        viewportBounds = rootViewportBounds,
                        gridPosition = featureLauncherGridPosition,
                        scrollState = featureLauncherScrollState,
                        excludedBounds = bottomChromeBounds[
                            rootUiState.liquidGlassBottomBarEnabled && rootUiState.liquidBackdrop != null
                        ]?.takeIf {
                            currentRootRoute == RootRoute.Main && it.width > 0f && it.height > 0f
                        },
                        onPressStart = { mode ->
                            // Monotonic ownership prevents a completed old leash
                            // from mistaking a newer press for its own token.
                            nextFeatureQueuePressToken += 1L
                            val pressToken = nextFeatureQueuePressToken
                            featureQueuePressTokens[mode] = pressToken
                            featureQueueHeldTokens[mode] = pressToken
                            featureTransitionScope.launch {
                                if (
                                    featureQueuePressTokens[mode] != pressToken ||
                                    featureQueueHeldTokens[mode] != pressToken
                                ) {
                                    return@launch
                                }
                                featureQueuePressScales.getValue(mode).animateTo(
                                    targetValue = 0.85f,
                                    animationSpec = tween(
                                        durationMillis = 200,
                                        easing = FastOutSlowInEasing,
                                    ),
                                )
                            }
                            pressToken
                        },
                        onPressEnd = { mode, pressToken ->
                            if (featureQueueHeldTokens[mode] == pressToken) {
                                featureQueueHeldTokens.remove(mode)
                            }
                            // An accepted launch owns this scale until the close
                            // leash reaches the icon. Releasing it here made old
                            // icons randomly resize underneath parallel windows.
                            releaseIconPress(mode, pressToken)
                        },
                        onOpen = { mode, origin, pressToken ->
                            openFeatureSubPageFromMain(
                                mode,
                                origin?.toLiveVisualOrigin(
                                    pressScale = featureQueuePressScales.getValue(mode).value,
                                    workspaceScale = workspaceVisualScale,
                                    viewportBounds = rootViewportBounds,
                                ),
                                pressToken = pressToken,
                            )
                        },
                    )
                }

                if (
                    activeAnimation?.direction == FeatureLaunchDirection.Opening ||
                    handFollowMotion != null
                ) {
                    // Launcher input is blocked for the whole OPEN / MULTI_OPEN
                    // state in C17. This full-window consumer also prevents an
                    // uncovered part of the transforming page from falling
                    // through to the still-mounted Main scene underneath.
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .pointerInput(Unit) {
                                detectTapGestures(
                                    onPress = { tryAwaitRelease() },
                                )
                            },
                    )
                }

                AnimatedVisibility(
                    visible = rootUiState.showFpsMonitor,
                    enter = fadeIn(),
                    exit = fadeOut(),
                ) {
                    FpsMonitorOverlay(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(top = 44.dp),
                    )
                }
            }
            val featureSessionRoute =
                (featureLaunchSession ?: parkedFeatureLaunchSession)?.mode?.toRootRoute()
            BackHandler(
                enabled = featureLaunchAnimation != null,
            ) {
                popRootRoute()
            }
            PredictiveBackHandler(
                enabled = featurePageNewStyleEnabled &&
                    featureLaunchAnimation == null &&
                    featureSessionRoute != null &&
                    (
                        navigator.current() == featureSessionRoute ||
                            featurePredictiveBackMotion != null
                        ),
            ) { progressEvents ->
                var gestureMotion: FeaturePredictiveBackMotion? = null
                try {
                    progressEvents.collect { event ->
                        val motion = gestureMotion ?: startFeaturePredictiveBack()
                            ?.also { gestureMotion = it }
                            ?: return@collect
                        updateFeaturePredictiveBack(motion, event)
                    }
                    val motion = gestureMotion
                    if (motion == null) {
                        // Three-button and hardware back have no progress
                        // stream; retain the normal full C17 close path.
                        popRootRoute()
                    } else {
                        commitFeaturePredictiveBack(motion)
                    }
                } catch (cancellation: CancellationException) {
                    gestureMotion?.let(::cancelFeaturePredictiveBack)
                    throw cancellation
                }
            }
        }
            }
        }
    }
    }
}
