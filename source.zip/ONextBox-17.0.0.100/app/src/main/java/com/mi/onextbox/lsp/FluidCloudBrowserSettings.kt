package com.mi.onextbox.lsp

import android.content.Context
import com.mi.onextbox.lsp.compat.HookConfigSnapshot

internal object FluidCloudBrowserSettings {
    const val PACKAGE_NAME = "com.coloros.colordirectservice"
    const val METIS_PACKAGE_NAME = "com.oplus.metis"
    val packages = listOf(PACKAGE_NAME, METIS_PACKAGE_NAME)
    const val ENABLED = "fluid_cloud_default_browser_enabled"

    fun isEnabled(context: Context): Boolean =
        LspPreferenceStore.prefs(context).getBoolean(ENABLED, false)

    fun setEnabled(context: Context, enabled: Boolean) {
        check(LspPreferenceStore.prefs(context).edit().putBoolean(ENABLED, enabled).commit())
        LspConfig.syncReadableState(context)
    }

    fun isEnabledXposed(): Boolean = HookConfigSnapshot.boolean(ENABLED, false) == true
}
