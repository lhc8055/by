# Display-only source build

This package keeps the existing ONextBox navigation and feature-page UI while disabling system modification hooks.

## Changes

- The main Features tab is forced to use the immersive icon-grid layout, including on ColorOS 16 devices.
- Existing feature destinations remain navigable; the dock and other tabs are not modified.
- The adaptation hook gate is disabled through `DISPLAY_ONLY_BUILD = true` in `AdaptationRuntimePolicy.kt`, so feature toggles cannot apply system-level modifications.
- Process/scope restart actions were removed from the Features pages.

## Re-enable real feature hooks later

In `app/src/main/java/com/mi/onextbox/lsp/compat/AdaptationRuntimePolicy.kt`, change:

```kotlin
internal const val DISPLAY_ONLY_BUILD: Boolean = true
```

to `false` only when you intentionally want to restore real system-modification behavior.

## Build

Open the project root in Android Studio and build the `app` debug variant. The source archive does not include a prebuilt APK.
