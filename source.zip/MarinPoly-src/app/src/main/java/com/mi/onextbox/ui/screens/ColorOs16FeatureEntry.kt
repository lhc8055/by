package com.mi.onextbox.ui.screens

import androidx.compose.runtime.Composable

/** ColorOS 16 main list. Rows only open (empty) pages. */
private val colorOs16MainPages = listOf(
    FeaturePageMode.Desktop,
    FeaturePageMode.SystemUi,
    FeaturePageMode.Settings,
    FeaturePageMode.PackageInstaller,
    FeaturePageMode.MobileNetwork,
    FeaturePageMode.AndroidSystem,
    FeaturePageMode.AppMarket,
    FeaturePageMode.Battery,
    FeaturePageMode.TrafficManagement,
    FeaturePageMode.PhoneManager,
    FeaturePageMode.ThemeStore,
    FeaturePageMode.SecurePay,
    FeaturePageMode.GameAssistant,
    FeaturePageMode.OShare,
    FeaturePageMode.SoftwareUpdate,
    FeaturePageMode.QuickAppServices,
    FeaturePageMode.FileManager,
    FeaturePageMode.SystemMessages,
    FeaturePageMode.AppErrors,
    FeaturePageMode.Athena,
    FeaturePageMode.SecurityPermission,
    FeaturePageMode.Wallpapers,
    FeaturePageMode.Aod,
    FeaturePageMode.Screenshot,
    FeaturePageMode.ScreenRecording,
    FeaturePageMode.Assistant,
)

@Composable
internal fun ColorOs16FeatureEntry(onOpen: (FeaturePageMode) -> Unit) {
    ColorOs16FeatureList(colorOs16MainPages, onOpen)
}

@Composable
private fun ColorOs16FeatureList(pages: List<FeaturePageMode>, onOpen: (FeaturePageMode) -> Unit) {
    FeatureAnimatedGroup {
        pages.forEach { page ->
            row(page) { above, below ->
                com.mi.onextbox.ui.settings.SettingsCardRow(
                    title = featurePageTitle(page), summary = "", showArrow = true,
                    onClick = { onOpen(page) }, hasDividerAbove = above, hasDividerBelow = below,
                )
            }
        }
    }
}
