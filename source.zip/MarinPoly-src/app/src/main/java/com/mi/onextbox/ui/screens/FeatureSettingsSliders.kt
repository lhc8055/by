package com.mi.onextbox.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mi.onextbox.ui.settings.SettingsRowTextContent
import com.mi.onextbox.ui.settings.settingsInteractionGate
import com.mi.onextbox.ui.settings.settingsInteractiveRowHighlight
import io.github.suqi8.coui.kmp.basic.Text
import io.github.suqi8.coui.kmp.theme.COUITheme

@Composable
internal fun ColorOsSettingsSliderRow(
    title: String,
    enabled: Boolean,
    hasDividerAbove: Boolean,
    hasDividerBelow: Boolean,
    heading: String? = null,
    titleAction: (@Composable () -> Unit)? = null,
    interactionEnabled: Boolean = true,
    content: @Composable () -> Unit,
) {
    val rowModifier = Modifier.settingsInteractionGate(interactionEnabled)
    val interactionSource = remember { MutableInteractionSource() }
    val titleAlpha by animateFloatAsState(
        targetValue = if (enabled) 1f else 0.38f,
        animationSpec = tween(durationMillis = 183),
        label = "ColorOsSettingsSliderTitleAlpha",
    )
    Column(
        modifier = rowModifier
            .fillMaxWidth()
            .settingsInteractiveRowHighlight(
                interactionSource = interactionSource,
                color = Color.Transparent,
                hasDividerAbove = hasDividerAbove,
                hasDividerBelow = hasDividerBelow,
            )
            .padding(horizontal = 16.dp),
    ) {
        if (heading != null) {
            Column(Modifier.padding(top = 10.dp)) {
                SettingsRowTextContent(title = heading, summary = null, enabled = enabled)
            }
        }
        Row(
            modifier = Modifier.padding(top = if (heading == null) 10.dp else 0.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = title,
                style = COUITheme.textStyles.title3,
                color = COUITheme.colorScheme.onSurface,
                fontWeight = FontWeight.Medium,
                fontSize = 15.sp,
                modifier = Modifier.weight(1f, fill = false).graphicsLayer { alpha = titleAlpha },
            )
            titleAction?.invoke()
        }
        content()
    }
}

@Composable
internal fun FeatureExpandableVisibility(
    visible: Boolean,
    content: @Composable () -> Unit,
) {
    AnimatedVisibility(
        visible = visible,
        enter = FeatureExpansionMotion.Enter,
        exit = FeatureExpansionMotion.Exit,
    ) {
        content()
    }
}
